(function(){
    // ---------- Data inicial (según PDF) ----------
    const SEED_VERSION = 'v2';
const SEED_PRODUCTS = [{"code": "CO001", "category": "Consolas", "name": "PlayStation 5", "price": 749990, "desc": "Consola PS5 lector de discos 825GB.", "stock": 6, "img": "https://via.placeholder.com/600x400?text=PS5"}, {"code": "CO002", "category": "Consolas", "name": "PlayStation 5 Digital", "price": 699990, "desc": "PS5 Digital Edition 825GB.", "stock": 5, "img": "https://via.placeholder.com/600x400?text=PS5+Digital"}, {"code": "CO003", "category": "Consolas", "name": "Xbox Series X", "price": 699990, "desc": "Consola Xbox Series X 1TB.", "stock": 5, "img": "https://via.placeholder.com/600x400?text=Xbox+Series+X"}, {"code": "CO004", "category": "Consolas", "name": "Nintendo Switch OLED", "price": 449990, "desc": "Switch OLED 64GB Neon.", "stock": 8, "img": "https://via.placeholder.com/600x400?text=Switch+OLED"}, {"code": "CO005", "category": "Consolas", "name": "Xbox Series S", "price": 359990, "desc": "Xbox Series S 512GB.", "stock": 9, "img": "https://via.placeholder.com/600x400?text=Xbox+Series+S"}, {"code": "PC001", "category": "Computadores Gamers", "name": "PC Gamer ASUS ROG", "price": 1499990, "desc": "Ryzen 7 · RTX 4060 · 16GB · 1TB SSD.", "stock": 3, "img": "https://via.placeholder.com/600x400?text=ASUS+ROG+PC"}, {"code": "PC002", "category": "Computadores Gamers", "name": "Alienware Aurora", "price": 2199990, "desc": "Intel i7 · RTX 4070 · 32GB · 1TB SSD.", "stock": 2, "img": "https://via.placeholder.com/600x400?text=Alienware+Aurora"}, {"code": "PC003", "category": "Computadores Gamers", "name": "MSI Katana 15", "price": 1199990, "desc": "i7 · RTX 4060 · 16GB · 512GB SSD.", "stock": 4, "img": "https://via.placeholder.com/600x400?text=MSI+Katana+15"}, {"code": "MN001", "category": "Monitores", "name": "Samsung Odyssey G5 27\" 144Hz", "price": 269990, "desc": "QHD 144Hz 1ms.", "stock": 7, "img": "https://via.placeholder.com/600x400?text=Odyssey+G5+27"}, {"code": "MN002", "category": "Monitores", "name": "LG Ultragear 27GL850 144Hz", "price": 289990, "desc": "QHD Nano IPS 144Hz.", "stock": 5, "img": "https://via.placeholder.com/600x400?text=LG+Ultragear+27"}, {"code": "MN003", "category": "Monitores", "name": "AOC 24G2 144Hz", "price": 159990, "desc": "FHD 144Hz 1ms.", "stock": 8, "img": "https://via.placeholder.com/600x400?text=AOC+24G2"}, {"code": "TK001", "category": "Teclados", "name": "Teclado Mecánico Red Dragon Kumara", "price": 39990, "desc": "Switch Red Outemu.", "stock": 15, "img": "https://via.placeholder.com/600x400?text=Kumara"}, {"code": "TK002", "category": "Teclados", "name": "Razer Huntsman Mini", "price": 119990, "desc": "60% óptico.", "stock": 6, "img": "https://via.placeholder.com/600x400?text=Huntsman+Mini"}, {"code": "TK003", "category": "Teclados", "name": "Logitech G PRO X", "price": 139990, "desc": "Hot‑swap GX.", "stock": 5, "img": "https://via.placeholder.com/600x400?text=G+PRO+X"}, {"code": "MS001", "category": "Mouse", "name": "Logitech G502 HERO", "price": 49990, "desc": "25K DPI RGB.", "stock": 12, "img": "https://via.placeholder.com/600x400?text=G502+HERO"}, {"code": "MS002", "category": "Mouse", "name": "Razer DeathAdder V2", "price": 59990, "desc": "Focus+ 20K DPI.", "stock": 10, "img": "https://via.placeholder.com/600x400?text=DeathAdder+V2"}, {"code": "MS003", "category": "Mouse", "name": "Glorious Model O", "price": 69990, "desc": "Ultraligero 67g.", "stock": 7, "img": "https://via.placeholder.com/600x400?text=Model+O"}, {"code": "MP001", "category": "Mousepad", "name": "Razer Goliathus Extended", "price": 39990, "desc": "Tamaño XL.", "stock": 14, "img": "https://via.placeholder.com/600x400?text=Goliathus+XL"}, {"code": "MP002", "category": "Mousepad", "name": "SteelSeries QcK Heavy", "price": 34990, "desc": "GRUESO XL.", "stock": 11, "img": "https://via.placeholder.com/600x400?text=QcK+Heavy"}, {"code": "AU001", "category": "Audio", "name": "HyperX Cloud II", "price": 79990, "desc": "7.1 virtual.", "stock": 10, "img": "https://via.placeholder.com/600x400?text=HyperX+Cloud+II"}, {"code": "AU002", "category": "Audio", "name": "SteelSeries Arctis 7", "price": 149990, "desc": "Inalámbricos 2.4GHz.", "stock": 6, "img": "https://via.placeholder.com/600x400?text=Arctis+7"}, {"code": "AC001", "category": "Accesorios", "name": "Control Xbox Series", "price": 69990, "desc": "Oficial Microsoft.", "stock": 16, "img": "https://via.placeholder.com/600x400?text=Control+Xbox"}, {"code": "AC002", "category": "Accesorios", "name": "DualSense PS5", "price": 79990, "desc": "Control Inalámbrico PS5.", "stock": 12, "img": "https://via.placeholder.com/600x400?text=DualSense+PS5"}, {"code": "AC003", "category": "Accesorios", "name": "Base Carga PS5", "price": 39990, "desc": "Dock para 2 controles.", "stock": 9, "img": "https://via.placeholder.com/600x400?text=Base+Carga+PS5"}, {"code": "SG001", "category": "Sillas Gamers", "name": "Secretlab Titan Evo", "price": 399990, "desc": "Ergonómica premium.", "stock": 3, "img": "https://via.placeholder.com/600x400?text=Secretlab+Titan+Evo"}, {"code": "SG002", "category": "Sillas Gamers", "name": "Corsair TC100", "price": 199990, "desc": "Tela, reclinable.", "stock": 5, "img": "https://via.placeholder.com/600x400?text=Corsair+TC100"}, {"code": "JM001", "category": "Juegos de Mesa", "name": "Catan", "price": 34990, "desc": "Explora y comercia.", "stock": 10, "img": "https://via.placeholder.com/600x400?text=Catan"}, {"code": "JM002", "category": "Juegos de Mesa", "name": "Carcassonne", "price": 29990, "desc": "Coloca losetas y domina.", "stock": 12, "img": "https://via.placeholder.com/600x400?text=Carcassonne"}, {"code": "JM003", "category": "Juegos de Mesa", "name": "Dixit", "price": 32990, "desc": "Cartas con ilustraciones oníricas.", "stock": 9, "img": "https://via.placeholder.com/600x400?text=Dixit"}, {"code": "JM004", "category": "Juegos de Mesa", "name": "UNO", "price": 9990, "desc": "Clásico familiar.", "stock": 30, "img": "https://via.placeholder.com/600x400?text=UNO"}, {"code": "JM005", "category": "Juegos de Mesa", "name": "Exploding Kittens", "price": 19990, "desc": "Cartas explosivas.", "stock": 15, "img": "https://via.placeholder.com/600x400?text=Exploding+Kittens"}, {"code": "RG001", "category": "Ropa Gamer", "name": "Polera LevelUp", "price": 14990, "desc": "Algodón, estampado frontal.", "stock": 20, "img": "https://via.placeholder.com/600x400?text=Polera+LevelUp"}, {"code": "RG002", "category": "Ropa Gamer", "name": "Polerón LevelUp", "price": 29990, "desc": "Canguro, capucha.", "stock": 12, "img": "https://via.placeholder.com/600x400?text=Poleron+LevelUp"}, {"code": "RG003", "category": "Ropa Gamer", "name": "Gorra LevelUp", "price": 12990, "desc": "Snapback.", "stock": 18, "img": "https://via.placeholder.com/600x400?text=Gorra+LevelUp"}, {"code": "TC001", "category": "Tarjetas", "name": "Gift Card PSN $20", "price": 19990, "desc": "Canjeable en PSN US.", "stock": 25, "img": "https://via.placeholder.com/600x400?text=PSN+20"}, {"code": "TC002", "category": "Tarjetas", "name": "Gift Card Xbox $25", "price": 21990, "desc": "Canjeable en Microsoft Store.", "stock": 22, "img": "https://via.placeholder.com/600x400?text=Xbox+25"}];


    // ---------- Utilidades ----------
    function formatCLP(n){ return n.toLocaleString('es-CL', {style:'currency', currency:'CLP'}); }
    function uid(prefix='id'){ return prefix + '_' + Math.random().toString(36).slice(2,10); }
    function todayYear(){ return new Date().getFullYear(); }

    // ---------- LocalStorage helpers ----------
    function dbGet(key, def=null){ try{ const v=localStorage.getItem(key); return v?JSON.parse(v):def; }catch(e){return def;} }
    function dbSet(key, val){ localStorage.setItem(key, JSON.stringify(val)); }

    // Initialize storage if empty
    if(!dbGet('lug_products')) dbSet('lug_products', PRODUCTS);
    if(!dbGet('lug_users')) dbSet('lug_users', []); // {id,name,email,password,birth,points,refCode,refBy,purchases:[],isDuoc}
    if(!dbGet('lug_cart')) dbSet('lug_cart', []); // {userId, items:[{code,qty,priceAt}] } or for guest userId=null
    if(!dbGet('lug_reviews')) dbSet('lug_reviews', []); // {id,productCode,userId,rating,text,date}
    if(!dbGet('lug_current')) dbSet('lug_current', {userId:null}); // current session

    // ---------- App state ----------
    let PRODUCTS_DB = dbGet('lug_products');
    const seedVer = localStorage.getItem('lug_seed_version');
    if(!PRODUCTS_DB || !Array.isArray(PRODUCTS_DB) || PRODUCTS_DB.length < 20 || seedVer !== SEED_VERSION){
      dbSet('lug_products', SEED_PRODUCTS);
      PRODUCTS_DB = SEED_PRODUCTS;
      localStorage.setItem('lug_seed_version', SEED_VERSION);
    }
    let USERS_DB = dbGet('lug_users');
    let REVIEWS_DB = dbGet('lug_reviews');
    let CURRENT = dbGet('lug_current');
    let CART = dbGet('lug_cart');

    // ---------- DOM refs ----------
    const productGrid = document.getElementById('product-grid');
    const categoryFilter = document.getElementById('category-filter');
    const priceFilter = document.getElementById('price-filter');
    const priceMaxLabel = document.getElementById('price-max-label');
    const filterInStock = document.getElementById('filter-in-stock');
    const searchInput = document.getElementById('search-input');
    const sortSelect = document.getElementById('sort-select');
    const cartCount = document.getElementById('cart-count');
    const btnCart = document.getElementById('btnCart');
    const cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
    
// Vaciar carrito
document.getElementById('clear-cart').addEventListener('click', ()=>{
  if(!confirm('¿Vaciar todo el carrito?')) return;
  saveCart([]);
  renderCartModal();
  updateCartBadge();
});

    const authModal = new bootstrap.Modal(document.getElementById('authModal'));
    const productModal = new bootstrap.Modal(document.getElementById('productModal'));
    const currentYearEl = document.getElementById('current-year');
    currentYearEl.textContent = todayYear();

    // ---------- UI Init ----------
    function initUI(){
      // hash category (e.g., #Accesorios)
      const hc = decodeURIComponent((location.hash||'').slice(1));
      if(hc){ const opt = Array.from(categoryFilter.options).find(o=>o.value===hc); if(opt){ categoryFilter.value = hc; } }
      window.addEventListener('hashchange', ()=>{ const h=decodeURIComponent((location.hash||'').slice(1)); if(h){ categoryFilter.value=h; } renderProducts(); });
      populateCategories();
      renderProducts();
      updateCartBadge();
      renderUserArea();
      renderQuickProfile();
      renderTopUsers();
      document.getElementById('wa-link').href = 'https://wa.me/569XXXXXXXX'; // replace if needed
    }

    // categories
    function populateCategories(){
      const cats = Array.from(new Set(PRODUCTS_DB.map(p=>p.category)));
      categoryFilter.innerHTML = '<option value="all">Todas</option>' + cats.map(c=>`<option value="${c}">${c}</option>`).join('');
      // price range max
      const maxPrice = Math.max(...PRODUCTS_DB.map(p=>p.price));
      priceFilter.max = Math.ceil(maxPrice/1000)*1000;
      priceFilter.value = priceFilter.max;
      priceMaxLabel.textContent = priceFilter.value.toLocaleString('es-CL');
    }

    // Product rendering with filters
    function renderProducts(){
      const q = searchInput.value.trim().toLowerCase();
      const cat = categoryFilter.value;
      const maxPrice = Number(priceFilter.value);
      const onlyStock = filterInStock.checked;
      let results = PRODUCTS_DB.filter(p=>{
        if(cat !== 'all' && p.category !== cat) return false;
        if(p.price > maxPrice) return false;
        if(onlyStock && (!p.stock || p.stock<=0)) return false;
        if(q && !(p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q) || p.code.toLowerCase().includes(q))) return false;
        return true;
      });
      // sort
      const sort = sortSelect.value;
      if(sort==='price-asc') results.sort((a,b)=>a.price-b.price);
      if(sort==='price-desc') results.sort((a,b)=>b.price-a.price);

      productGrid.innerHTML = results.map(p=>productCardHtml(p)).join('');
      // attach buttons
      document.querySelectorAll('.btn-add').forEach(btn=>{
        btn.addEventListener('click', e=>{
          const code = e.currentTarget.dataset.code; addToCart(code,1); });
      });
      document.querySelectorAll('.product-open').forEach(btn=>{
        btn.addEventListener('click', e=>{ openProductModal(e.currentTarget.dataset.code); });
      });
    }

    function productCardHtml(p){
      const critico = (p.stock!=null && p.stock<=3);
      const sinStock = (!p.stock || p.stock<=0);
      const stockChip = sinStock ? `<span class="badge bg-danger ms-2">Sin stock</span>` : (critico ? `<span class="badge bg-warning text-dark ms-2">Stock crítico</span>` : ``);

      // average rating
      const reviews = REVIEWS_DB.filter(r=>r.productCode === p.code);
      const avg = reviews.length? (reviews.reduce((s,r)=>s+r.rating,0)/reviews.length).toFixed(1) : '—';
      return `
        <div class="col-md-4">
          <div class="card card-product h-100 p-2">
            <img onerror="this.onerror=null;this.src='https://via.placeholder.com/600x400?text=LevelUp+Gamer';" class="img-fluid rounded" src="${p.img}" alt="${p.name}">
            <div class="mt-2 d-flex justify-content-between align-items-start">
              <div>
                <h5 class="mb-1">${p.name}</h5>
                <div class="muted small">${p.category} • ${p.code}</div>
              </div>
              <div class="text-end">
                <div class="h6">${formatCLP(p.price)}</div>
                <div class="muted small">${p.stock>0? 'En stock' : 'Agotado'}</div>
              </div>
            </div>
            <p class="mt-2">${p.desc}</p>
            <div class="d-flex justify-content-between align-items-center">
              <div class="small muted">⭐ ${avg} (${reviews.length})</div>
              <div>
                <button class="btn btn-sm btn-outline-light product-open" data-code="${p.code}">Ver</button>
                <button class="btn btn-sm btn-gamer btn-add" data-code="${p.code}" ${p.stock<=0? 'disabled':''}>Agregar</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }

    // ---------- Cart ----------
    function getCartForCurrent(){
      // we'll keep single global cart for demo. CART is array of items for guest or keyed by user
      let cart = dbGet('lug_cart') || [];
      // choose current cart (we'll use single cart object with items)
      // Keep simple: array of items {code,qty}
      if(!cart || !Array.isArray(cart)) cart = [];
      return cart;
    }
    function saveCart(cart){
      dbSet('lug_cart', cart);
      CART = cart;
      updateCartBadge();
    }

    function addToCart(code, qty=1){
      const product = PRODUCTS_DB.find(p=>p.code===code);
      if(!product) return alert('Producto no encontrado');
      let cart = getCartForCurrent();
      const existing = cart.find(i=>i.code===code);
      if(existing){
        existing.qty = Math.min(product.stock, existing.qty + qty);
      } else {
        cart.push({ code: code, qty: Math.min(product.stock, qty), priceAt: product.price });
      }
      saveCart(cart);
      renderCartModal();
      alert('Producto agregado al carrito');
    }

    function updateCartBadge(){
      const cart = getCartForCurrent();
      const totalQty = cart.reduce((s,i)=>s+i.qty,0);
      cartCount.textContent = totalQty;
    }

    btnCart.addEventListener('click', ()=>{
      renderCartModal();
      cartModal.show();
    });

    function renderCartModal(){
      const cart = getCartForCurrent();
      const el = document.getElementById('cart-items');
      if(cart.length===0){
        el.innerHTML = '<div class="muted">Tu carrito está vacío.</div>';
        document.getElementById('cart-summary').innerHTML = '';
        return;
      }
      let html = '<div class="table-responsive"><table class="table table-dark table-striped"><thead><tr><th>Producto</th><th>Precio</th><th>Cantidad</th><th>Subtotal</th><th></th></tr></thead><tbody>';
      let subtotal = 0;
      cart.forEach(item=>{
        const p = PRODUCTS_DB.find(pp=>pp.code===item.code);
        const st = (item.qty * (item.priceAt || p.price));
        subtotal += st;
        html += `<tr data-code="${item.code}"><td>${p.name}</td><td>${formatCLP(item.priceAt || p.price)}</td><td><input class="form-control form-control-sm qty-input" style="width:80px" data-code="${item.code}" value="${item.qty}" type="number" min="1" max="${p.stock}"></td><td>${formatCLP(st)}</td><td><button class="btn btn-sm btn-danger remove-item" data-code="${item.code}">Eliminar</button></td></tr>`;
      });
      html += '</tbody></table></div>';
      el.innerHTML = html;

      // summary: apply duoc discount if user has duoc
      let discount = 0;
      const curUser = getCurrentUser();
      const isDuoc = curUser && curUser.isDuoc;
      if(isDuoc) discount = Math.round(subtotal * 0.20);
      const total = subtotal - discount;

      document.getElementById('cart-summary').innerHTML = `<div>Subtotal: <strong>${formatCLP(subtotal)}</strong></div>
        <div>Descuento Duoc 20%: <strong>${formatCLP(discount)}</strong></div>
        <div class="mt-2 h5">Total: <strong>${formatCLP(total)}</strong></div>`;

      // attach listeners
      document.querySelectorAll('.remove-item').forEach(btn=> btn.addEventListener('click', e=>{
        const code = e.currentTarget.dataset.code;
        removeFromCart(code);
      }));
      document.querySelectorAll('.qty-input').forEach(inp=>{
        inp.addEventListener('change', e=>{
          const code = e.currentTarget.dataset.code;
          let v = Number(e.currentTarget.value);
          if(v<1) v=1;
          const p = PRODUCTS_DB.find(pp=>pp.code===code);
          if(v>p.stock){ v=p.stock; e.currentTarget.value = v; alert('No hay tanto stock'); }
          updateCartQty(code, v);
        });
      });
    }

    function removeFromCart(code){
      let cart = getCartForCurrent();
      cart = cart.filter(i=>i.code!==code);
      saveCart(cart);
      renderCartModal();
    }
    function updateCartQty(code, qty){
      let cart = getCartForCurrent();
      const it = cart.find(i=>i.code===code);
      if(it){ it.qty = qty; saveCart(cart); renderCartModal(); }
    }

    // Checkout (simulado)
    document.getElementById('checkout-btn').addEventListener('click', ()=>{
      const current = getCurrentUser();
      if(!current) return alert('Debes iniciar sesión para comprar — demo requiere usuario.');
      const cart = getCartForCurrent();
      if(cart.length===0) return alert('Carrito vacío');
      // reduce stock, save purchase in user's purchases, award points
      let subtotal = 0;
      cart.forEach(it=>{
        const p = PRODUCTS_DB.find(pp=>pp.code===it.code);
        subtotal += it.qty * (it.priceAt || p.price);
        p.stock = Math.max(0, p.stock - it.qty);
      });
      // calculate discount
      const isDuoc = current.isDuoc;
      const discount = isDuoc ? Math.round(subtotal * 0.20) : 0;
      const total = subtotal - discount;
      // award points: 1 punto por cada 1000 CLP gastado (redondeo)
      const pointsEarned = Math.floor(total / 1000);
      // store purchase
      const purchase = { id: uid('pur'), date: new Date().toISOString(), items: cart, subtotal, discount, total, points: pointsEarned };
      // save to user
      const users = dbGet('lug_users');
      const uidx = users.findIndex(u=>u.id===current.userId);
      if(uidx>=0){
        users[uidx].purchases = users[uidx].purchases || [];
        users[uidx].purchases.push(purchase);
        users[uidx].points = (users[uidx].points||0) + pointsEarned;
        dbSet('lug_users', users);
      }
      // clear cart
      saveCart([]);
      // update products DB (stocks)
      dbSet('lug_products', PRODUCTS_DB);
      alert(`Compra realizada (demo). Total ${formatCLP(total)}. Ganaste ${pointsEarned} puntos LevelUp.`);
      // refresh UI
      PRODUCTS_DB = dbGet('lug_products');
      USERS_DB = dbGet('lug_users');
      renderProducts();
      renderUserArea();
      renderTopUsers();
      renderQuickProfile();
      renderPurchaseHistory();
      cartModal.hide();
    });

    // ---------- Auth / Register ----------
    document.getElementById('open-register').addEventListener('click', ()=> authModal.show());

    document.getElementById('btn-register').addEventListener('click', ()=>{
      const name = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim().toLowerCase();
      const password = document.getElementById('reg-password').value;
      const birth = document.getElementById('reg-birth').value;
      const ref = document.getElementById('reg-ref').value.trim();

      if(!name||!email||!password||!birth) return document.getElementById('reg-msg').textContent = 'Completa todos los campos';
      // age check
      const bdate = new Date(birth);
      const age = getAge(bdate);
      if(age < 18) return document.getElementById('reg-msg').textContent = 'Debes ser mayor de 18 años para registrarte.';
      // unique email
      let users = dbGet('lug_users')||[];
      if(users.some(u=>u.email===email)) return document.getElementById('reg-msg').textContent = 'Ese email ya está registrado.';
      // Duoc email check
      const isDuoc = email.includes('@duoc') || email.endsWith('.duoc.cl') || email.includes('@duocuc'); // basic detection
      const newUser = {
        id: uid('u'),
        name, email, password, birth: bdate.toISOString(),
        points: 0,
        refCode: generateRefCode(),
        refBy: ref || null,
        purchases: [],
        isDuoc: !!isDuoc
      };
      users.push(newUser);
      // if used a valid ref code, give points to the referer
      if(ref){
        const idx = users.findIndex(u=>u.refCode === ref);
        if(idx>=0){
          users[idx].points = (users[idx].points||0) + 50; // example: 50 puntos por referido
          newUser.refBy = ref;
          newUser.points = (newUser.points||0) + 25; // referido también obtiene 25 pts
        }
      }
      dbSet('lug_users', users);
      // set current session
      dbSet('lug_current', { userId: newUser.id });
      CURRENT = dbGet('lug_current');
      USERS_DB = dbGet('lug_users');
      document.getElementById('reg-msg').textContent = 'Cuenta creada. Has iniciado sesión.';
      renderUserArea();
      renderQuickProfile();
      renderTopUsers();
      setTimeout(()=> authModal.hide(), 800);
    });

    document.getElementById('btn-login').addEventListener('click', ()=>{
      const email = document.getElementById('login-email').value.trim().toLowerCase();
      const pwd = document.getElementById('login-password').value;
      const users = dbGet('lug_users')||[];
      const u = users.find(x=>x.email===email && x.password===pwd);
      if(!u) return document.getElementById('login-msg').textContent = 'Credenciales incorrectas';
      dbSet('lug_current', { userId: u.id });
      CURRENT = dbGet('lug_current');
      document.getElementById('login-msg').textContent = 'Sesión iniciada';
      renderUserArea();
      renderQuickProfile();
      renderPurchaseHistory();
      setTimeout(()=> authModal.hide(), 700);
    });

    function getAge(bdate){
      const diff = Date.now() - bdate.getTime();
      const ageDt = new Date(diff);
      return Math.abs(ageDt.getUTCFullYear() - 1970);
    }
    function generateRefCode(){
      return Math.random().toString(36).slice(2,8).toUpperCase();
    }

    function getCurrentUser(){
      const cur = dbGet('lug_current') || {userId:null};
      if(!cur.userId) return null;
      const users = dbGet('lug_users') || [];
      return users.find(u=>u.id===cur.userId) || null;
    }

    // Render user area in navbar
    function renderUserArea(){
      const ua = document.getElementById('user-area');
      ua.innerHTML = '';
      const cur = getCurrentUser();
      if(cur){
        const nameBadge = document.createElement('div');
        nameBadge.className = 'd-flex align-items-center gap-2';
        nameBadge.innerHTML = `<div class="level-bubble">Nivel: ${getLevel(cur.points)}</div><div class="small muted">${cur.name}</div> <button id="btn-profile" class="btn btn-sm btn-outline-light">Perfil</button> <button id="btn-logout" class="btn btn-sm btn-danger">Salir</button>`;
        ua.appendChild(nameBadge);

        document.getElementById('btn-logout').addEventListener('click', ()=>{
          dbSet('lug_current', { userId: null });
          CURRENT = dbGet('lug_current');
          renderUserArea();
          renderQuickProfile();
          renderPurchaseHistory();
        });
        document.getElementById('btn-profile').addEventListener('click', ()=> openProfile());
      } else {
        const logBtn = document.createElement('div');
        logBtn.innerHTML = '<button class="btn btn-outline-light btn-sm" id="open-auth">Entrar / Registrarse</button>';
        ua.appendChild(logBtn);
        document.getElementById('open-auth').addEventListener('click', ()=> authModal.show());
      }
    }

    function getLevel(points){
      if(!points) return 1;
      if(points < 100) return 1;
      if(points < 500) return 2;
      if(points < 1000) return 3;
      return 4;
    }

    // Quick profile in sidebar
    function renderQuickProfile(){
      const el = document.getElementById('quick-profile');
      const cur = getCurrentUser();
      if(!cur){
        el.innerHTML = `<div class="muted small">No has iniciado sesión.</div><div class="mt-2"><button class="btn btn-sm btn-outline-light" onclick="(function(){document.querySelector('#open-register').click();})()">Inicia sesión</button></div>`;
        return;
      }
      el.innerHTML = `<div><strong>${cur.name}</strong></div>
        <div class="muted small">${cur.email}</div>
        <div class="mt-1"><span class="badge badge-points">${cur.points || 0} pts</span> <span class="ms-2 muted small">Código referido: <strong>${cur.refCode}</strong></span></div>`;
    }

    // Profile modal replacement: simple profile editor using prompt for demo
    function openProfile(){
      const cur = getCurrentUser();
      if(!cur) return alert('No has iniciado sesión.');
      const users = dbGet('lug_users');
      const idx = users.findIndex(u=>u.id===cur.id);
      const newName = prompt('Nombre:', cur.name) || cur.name;
      const newEmail = prompt('Email:', cur.email) || cur.email;
      // cannot change birth easily here; allow toggling
      users[idx].name = newName;
      users[idx].email = newEmail;
      dbSet('lug_users', users);
      renderUserArea();
      renderQuickProfile();
      alert('Perfil actualizado (demo).');
    }

    // Top users
    function renderTopUsers(){
      const el = document.getElementById('top-users');
      const users = dbGet('lug_users') || [];
      const sorted = users.slice().sort((a,b)=> (b.points||0)-(a.points||0)).slice(0,5);
      el.innerHTML = sorted.map(u=>`<li class="mb-1">${u.name} — <span class="badge badge-points">${u.points||0} pts</span> <small class="muted">Nivel ${getLevel(u.points||0)}</small></li>`).join('');
    }

    // Purchase history for current user
    function renderPurchaseHistory(){
      const cur = getCurrentUser();
      const el = document.getElementById('purchase-history');
      if(!cur) { el.innerHTML = 'Inicia sesión y compra para ver tu historial.'; return; }
      const users = dbGet('lug_users');
      const u = users.find(x=>x.id===cur.id);
      if(!u || !u.purchases || u.purchases.length===0) { el.innerHTML = 'Aún no tienes compras.'; return; }
      el.innerHTML = u.purchases.map(p=>`<div class="mb-2"><strong>${new Date(p.date).toLocaleString()}</strong> — Total: ${formatCLP(p.total)} — Puntos: ${p.points}</div>`).join('');
    }

    // ---------- Product Modal + Reviews ----------
    function openProductModal(code){
      const p = PRODUCTS_DB.find(x=>x.code===code);
      if(!p) return;
      document.getElementById('productModalTitle').textContent = `${p.name} • ${p.code}`;
      const pmimg = document.getElementById('productModalImg'); pmimg.src = p.img; pmimg.onerror = ()=>{ pmimg.onerror=null; pmimg.src='https://via.placeholder.com/800x500?text=LevelUp+Gamer'; };
      document.getElementById('productModalPrice').textContent = formatCLP(p.price);
      document.getElementById('productModalCategory').textContent = p.category;
      document.getElementById('productModalStock').textContent = p.stock>0? p.stock : 'Agotado';
      document.getElementById('productModalDesc').textContent = p.desc;
      document.getElementById('pm-add-to-cart').dataset.code = p.code;
      document.getElementById('pm-add-to-cart').onclick = ()=>{ addToCart(p.code,1); productModal.hide(); };

      // render reviews
      const reviews = (dbGet('lug_reviews') || []).filter(r=>r.productCode === p.code).sort((a,b)=>new Date(b.date)-new Date(a.date));
      const revHtml = reviews.length ? reviews.map(r=> {
        const user = (dbGet('lug_users')||[]).find(u=>u.id===r.userId) || {name:'Anon'};
        return `<div class="mb-2 p-2" style="background:rgba(255,255,255,0.02); border-radius:6px;">
          <div><strong>${user.name}</strong> <small class="muted">• ${new Date(r.date).toLocaleString()}</small></div>
          <div> ${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)} </div>
          <div class="mt-1">${r.text}</div>
        </div>`;
      }).join('') : '<div class="muted">Aún no hay reseñas para este producto.</div>';
      document.getElementById('product-reviews').innerHTML = revHtml;

      // leave review area: only allow if logged and has purchased this product
      const cur = getCurrentUser();
      const leave = document.getElementById('leave-review-area');
      leave.innerHTML = '';
      if(!cur){
        leave.innerHTML = '<div class="muted">Inicia sesión para dejar una reseña.</div>';
      } else {
        const users = dbGet('lug_users')||[];
        const u = users.find(uu=>uu.id===cur.id);
        const hasBought = (u && u.purchases && u.purchases.some(pur=> pur.items && pur.items.some(it=> it.code === code)));
        if(!hasBought){
          leave.innerHTML = '<div class="muted">Solo puedes reseñar productos que has comprado.</div>';
        } else {
          leave.innerHTML = `
            <div><label class="form-label">Tu calificación</label>
            <select id="review-rating" class="form-select form-control-dark mb-2">
              <option value="5">5 - Excelente</option>
              <option value="4">4 - Muy bueno</option>
              <option value="3">3 - Bueno</option>
              <option value="2">2 - Regular</option>
              <option value="1">1 - Malo</option>
            </select></div>
            <div><textarea id="review-text" class="form-control form-control-dark" rows="3" placeholder="Escribe tu reseña..."></textarea></div>
            <div class="mt-2"><button id="send-review" class="btn btn-gamer">Enviar reseña</button></div>`;
          document.getElementById('send-review').addEventListener('click', ()=>{
            const rating = Number(document.getElementById('review-rating').value);
            const text = document.getElementById('review-text').value.trim();
            if(!text) return alert('Escribe algo de texto para la reseña');
            const newRev = { id: uid('rev'), productCode: code, userId: cur.id, rating, text, date: new Date().toISOString() };
            const revs = dbGet('lug_reviews') || [];
            revs.push(newRev);
            dbSet('lug_reviews', revs);
            REVIEWS_DB = revs;
            alert('Reseña publicada');
            openProductModal(code);
          });
        }
      }

      productModal.show();
    }

    // ---------- Reviews DB already stored in localStorage ----------

    // ---------- Events listeners ----------
    searchInput.addEventListener('input', ()=> renderProducts());
    categoryFilter.addEventListener('change', ()=> renderProducts());
    priceFilter.addEventListener('input', ()=> { priceMaxLabel.textContent = Number(priceFilter.value).toLocaleString('es-CL'); renderProducts(); });
    filterInStock.addEventListener('change', ()=> renderProducts());
    sortSelect.addEventListener('change', ()=> renderProducts());

    // ----------------- Init app -----------------
    initUI();
    renderPurchaseHistory();

    // expose some functions for inline triggers (small hack)
    window.openProductModal = openProductModal;
    window.addToCart = addToCart;

  })();
