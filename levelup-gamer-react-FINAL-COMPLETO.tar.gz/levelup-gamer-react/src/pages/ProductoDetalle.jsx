import { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useProducts, useSession } from '../hooks/useLocalStorage';
import { useCart } from '../hooks/useCart';
import { useReviews } from '../hooks/useReviews';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function ProductoDetalle() {
  const location = useLocation();
  const navigate = useNavigate();
  const productId = parseInt(new URLSearchParams(location.search).get('id'));
  const [products] = useProducts();
  const { addToCart } = useCart();
  const { session } = useSession();
  const {
    getProductReviews,
    getProductRating,
    hasUserReviewed,
    addReview,
    editReview,
    deleteReview,
    markAsHelpful
  } = useReviews();

  const [product, setProduct] = useState(null);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [editingReview, setEditingReview] = useState(null);

  useEffect(() => {
    const prod = products.find(p => p.id === productId);
    if (!prod) {
      alert('Producto no encontrado');
      navigate('/productos');
      return;
    }
    setProduct(prod);
  }, [productId, products, navigate]);

  if (!product) {
    return (
      <>
        <Header />
        <main className="section">
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <p>Cargando producto...</p>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  const reviews = getProductReviews(productId);
  const avgRating = getProductRating(productId);
  const userHasReviewed = session ? hasUserReviewed(productId, session.id) : false;

  const handleAddToCart = () => {
    addToCart(product);
    alert('✅ Producto añadido al carrito');
  };

  const handleSubmitReview = (e) => {
    e.preventDefault();
    
    if (!session) {
      alert('Debes iniciar sesión para dejar una reseña');
      return;
    }

    if (editingReview) {
      const result = editReview(productId, editingReview.id, session.id, rating, comment);
      if (result.success) {
        alert(result.message);
        setEditingReview(null);
        setShowReviewForm(false);
        setRating(5);
        setComment('');
      } else {
        alert(result.message);
      }
    } else {
      const result = addReview(productId, session.id, session.nombre, rating, comment);
      if (result.success) {
        alert(result.message);
        setShowReviewForm(false);
        setRating(5);
        setComment('');
      } else {
        alert(result.message);
      }
    }
  };

  const handleEditReview = (review) => {
    setEditingReview(review);
    setRating(review.rating);
    setComment(review.comment);
    setShowReviewForm(true);
  };

  const handleDeleteReview = (reviewId) => {
    if (!confirm('¿Estás seguro de eliminar esta reseña?')) return;
    
    const result = deleteReview(productId, reviewId, session.id);
    if (result.success) {
      alert(result.message);
    } else {
      alert(result.message);
    }
  };

  const handleCancelEdit = () => {
    setEditingReview(null);
    setShowReviewForm(false);
    setRating(5);
    setComment('');
  };

  const renderStars = (rating, interactive = false, onHover = null) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span
          key={i}
          style={{
            fontSize: interactive ? '2em' : '1.2em',
            color: i <= rating ? '#FFD700' : '#555',
            cursor: interactive ? 'pointer' : 'default',
            transition: 'all 0.2s'
          }}
          onClick={interactive ? () => setRating(i) : undefined}
          onMouseEnter={interactive && onHover ? () => onHover(i) : undefined}
        >
          ★
        </span>
      );
    }
    return stars;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CL', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const stockWarn = (product.stockCritico != null && product.stock <= product.stockCritico);

  return (
    <>
      <Header />
      
      <main className="section">
        <button 
          onClick={() => navigate('/productos')} 
          className="btn-secondary"
          style={{ marginBottom: '20px' }}
        >
          ← Volver al catálogo
        </button>

        <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: '40px', alignItems: 'start' }}>
          {/* Imagen del producto */}
          <div style={{ position: 'relative' }}>
            <img 
              src={product.img} 
              alt={product.nombre} 
              style={{ 
                width: '100%', 
                borderRadius: '12px',
                boxShadow: '0 10px 30px rgba(0,0,0,0.3)'
              }} 
            />
            {stockWarn && (
              <span style={{
                position: 'absolute',
                top: '20px',
                right: '20px',
                background: 'rgba(255, 0, 0, 0.9)',
                color: '#fff',
                padding: '10px 20px',
                borderRadius: '8px',
                fontSize: '1em',
                fontWeight: '700'
              }}>
                ⚠️ STOCK BAJO
              </span>
            )}
          </div>

          {/* Información del producto */}
          <div className="stack">
            <div>
              <span className="muted" style={{ fontSize: '0.9em' }}>
                {product.categoria} • Código: {product.codigo}
              </span>
              <h1 style={{ fontSize: '2.5em', marginTop: '10px', marginBottom: '20px' }}>
                {product.nombre}
              </h1>
            </div>

            {/* Rating promedio */}
            {reviews.length > 0 && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
                <div>{renderStars(Math.round(avgRating))}</div>
                <span style={{ fontSize: '1.2em', fontWeight: '700', color: '#FFD700' }}>
                  {avgRating}
                </span>
                <span className="muted">
                  ({reviews.length} {reviews.length === 1 ? 'reseña' : 'reseñas'})
                </span>
              </div>
            )}

            <div className="card p" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: '2.5em', fontWeight: '700', color: '#fff' }}>
                    {CLP.format(product.precio)}
                  </div>
                  <div style={{ color: 'rgba(255,255,255,0.9)', marginTop: '5px' }}>
                    Stock disponible: <strong>{product.stock}</strong> unidades
                  </div>
                </div>
              </div>
            </div>

            <button 
              className="btn-primary" 
              onClick={handleAddToCart}
              style={{ fontSize: '1.2em', padding: '15px' }}
            >
              🛒 Añadir al carrito
            </button>

            <div className="card p">
              <h3>Descripción</h3>
              <p style={{ lineHeight: '1.6', color: 'rgba(255,255,255,0.8)' }}>
                {product.descripcion}
              </p>
            </div>
          </div>
        </div>

        {/* Sección de reseñas */}
        <div style={{ marginTop: '60px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
            <h2>📝 Reseñas de clientes</h2>
            {session && !userHasReviewed && !showReviewForm && (
              <button 
                className="btn-primary"
                onClick={() => setShowReviewForm(true)}
              >
                Escribir reseña
              </button>
            )}
          </div>

          {/* Formulario de reseña */}
          {showReviewForm && session && (
            <div className="card p" style={{ marginBottom: '30px', background: 'rgba(0, 212, 255, 0.05)', border: '1px solid #00d4ff' }}>
              <h3>{editingReview ? 'Editar reseña' : 'Escribe tu reseña'}</h3>
              <form onSubmit={handleSubmitReview} className="stack">
                <div>
                  <label style={{ display: 'block', marginBottom: '10px', fontWeight: '600' }}>
                    Calificación *
                  </label>
                  <div style={{ display: 'flex', gap: '5px' }}>
                    {renderStars(rating, true)}
                  </div>
                </div>

                <div>
                  <label style={{ display: 'block', marginBottom: '10px', fontWeight: '600' }}>
                    Comentario (opcional)
                  </label>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Comparte tu experiencia con este producto..."
                    rows="5"
                    maxLength="500"
                    style={{ 
                      width: '100%', 
                      padding: '12px', 
                      borderRadius: '8px', 
                      border: '1px solid #333', 
                      background: '#222', 
                      color: '#fff',
                      resize: 'vertical'
                    }}
                  />
                  <div className="muted" style={{ fontSize: '0.85em', marginTop: '5px' }}>
                    {comment.length}/500 caracteres
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button type="submit" className="btn-primary">
                    {editingReview ? 'Actualizar reseña' : 'Publicar reseña'}
                  </button>
                  <button 
                    type="button" 
                    className="btn-secondary"
                    onClick={handleCancelEdit}
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Lista de reseñas */}
          {reviews.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
              <div style={{ fontSize: '3em', marginBottom: '20px' }}>💬</div>
              <p>Aún no hay reseñas para este producto.</p>
              <p className="muted" style={{ marginTop: '10px' }}>
                ¡Sé el primero en compartir tu opinión!
              </p>
            </div>
          ) : (
            <div className="stack">
              {reviews
                .sort((a, b) => new Date(b.date) - new Date(a.date))
                .map(review => (
                  <div key={review.id} className="card p">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '15px' }}>
                      <div>
                        <div style={{ fontWeight: '700', fontSize: '1.1em' }}>
                          {review.userName}
                        </div>
                        <div className="muted" style={{ fontSize: '0.9em', marginTop: '5px' }}>
                          {formatDate(review.date)}
                          {review.editedAt && ' (editado)'}
                        </div>
                      </div>
                      <div>{renderStars(review.rating)}</div>
                    </div>

                    {review.comment && (
                      <p style={{ 
                        lineHeight: '1.6', 
                        color: 'rgba(255,255,255,0.8)',
                        marginBottom: '15px'
                      }}>
                        {review.comment}
                      </p>
                    )}

                    <div style={{ display: 'flex', gap: '15px', alignItems: 'center', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '15px' }}>
                      <button
                        onClick={() => markAsHelpful(productId, review.id)}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: 'rgba(255,255,255,0.6)',
                          cursor: 'pointer',
                          fontSize: '0.9em',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '5px'
                        }}
                      >
                        👍 Útil ({review.helpful})
                      </button>

                      {session && review.userId === session.id && (
                        <>
                          <button
                            onClick={() => handleEditReview(review)}
                            className="btn-secondary"
                            style={{ padding: '5px 15px', fontSize: '0.85em' }}
                          >
                            Editar
                          </button>
                          <button
                            onClick={() => handleDeleteReview(review.id)}
                            className="btn-secondary"
                            style={{ padding: '5px 15px', fontSize: '0.85em', color: '#ff4444' }}
                          >
                            Eliminar
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </>
  );
}

export default ProductoDetalle;
