import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useSession } from '../hooks/useLocalStorage';
import { useLoyaltyPoints } from '../hooks/useLoyaltyPoints';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function MisPuntos() {
  const { session } = useSession();
  const navigate = useNavigate();
  const { 
    getUserPoints, 
    getUserHistory, 
    getMaxDiscount,
    POINTS_PER_1000_CLP,
    POINTS_TO_DISCOUNT 
  } = useLoyaltyPoints();

  // Redirigir si no hay sesión
  if (!session) {
    setTimeout(() => {
      alert('Debes iniciar sesión para ver tus puntos');
      navigate('/login');
    }, 100);
    return null;
  }

  const userPoints = getUserPoints(session.id);
  const history = getUserHistory(session.id);
  const maxDiscount = getMaxDiscount(session.id);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CL', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const totalEarned = history
    .filter(t => t.type === 'earn')
    .reduce((sum, t) => sum + t.points, 0);

  const totalRedeemed = Math.abs(
    history
      .filter(t => t.type === 'redeem')
      .reduce((sum, t) => sum + t.points, 0)
  );

  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">💎 Mis Puntos de Fidelidad</h1>

        <div className="grid" style={{ gridTemplateColumns: '1fr 2fr', gap: '20px', alignItems: 'start' }}>
          {/* Panel de puntos */}
          <div className="stack">
            <div className="card p" style={{ 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
              border: 'none',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '0.9em', color: 'rgba(255,255,255,0.9)', marginBottom: '10px' }}>
                Puntos disponibles
              </div>
              <div style={{ fontSize: '4em', fontWeight: '700', color: '#fff' }}>
                {userPoints}
              </div>
              <div style={{ 
                marginTop: '20px', 
                padding: '15px', 
                background: 'rgba(255,255,255,0.1)', 
                borderRadius: '8px' 
              }}>
                <div style={{ color: 'rgba(255,255,255,0.9)', fontSize: '0.9em' }}>
                  Descuento disponible
                </div>
                <div style={{ fontSize: '1.8em', fontWeight: '700', color: '#fff', marginTop: '5px' }}>
                  {CLP.format(maxDiscount)}
                </div>
              </div>
            </div>

            <div className="card p">
              <h3>📊 Resumen</h3>
              <div className="stack">
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  padding: '10px 0',
                  borderBottom: '1px solid rgba(255,255,255,0.1)'
                }}>
                  <span>Puntos ganados</span>
                  <strong style={{ color: '#4ade80' }}>+{totalEarned}</strong>
                </div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  padding: '10px 0',
                  borderBottom: '1px solid rgba(255,255,255,0.1)'
                }}>
                  <span>Puntos canjeados</span>
                  <strong style={{ color: '#f87171' }}>-{totalRedeemed}</strong>
                </div>
                <div style={{ 
                  display: 'flex', 
                  justifyContent: 'space-between',
                  padding: '10px 0'
                }}>
                  <span>Balance actual</span>
                  <strong style={{ color: '#00d4ff', fontSize: '1.2em' }}>{userPoints}</strong>
                </div>
              </div>
            </div>

            <div className="card p" style={{ background: 'rgba(0, 212, 255, 0.05)', border: '1px solid #00d4ff' }}>
              <h3>💡 ¿Cómo funciona?</h3>
              <ul style={{ lineHeight: '1.8', color: 'rgba(255,255,255,0.8)' }}>
                <li>Ganas <strong>{POINTS_PER_1000_CLP} punto</strong> por cada <strong>$1.000</strong> gastados</li>
                <li>Canjea <strong>{POINTS_TO_DISCOUNT} puntos</strong> por <strong>$10.000</strong> de descuento</li>
                <li>Los puntos se acumulan automáticamente con cada compra</li>
                <li>Puedes canjear tus puntos en el carrito</li>
              </ul>
            </div>

            <button 
              className="btn-primary"
              onClick={() => navigate('/productos')}
              style={{ width: '100%' }}
            >
              🛒 Ir a comprar
            </button>
          </div>

          {/* Historial de transacciones */}
          <div className="stack">
            <div className="card p">
              <h2>📜 Historial de Puntos</h2>
              
              {history.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <div style={{ fontSize: '3em', marginBottom: '20px' }}>🎯</div>
                  <p>Aún no tienes movimientos de puntos.</p>
                  <p className="muted" style={{ marginTop: '10px' }}>
                    ¡Realiza tu primera compra para empezar a acumular puntos!
                  </p>
                  <button 
                    className="btn-primary"
                    onClick={() => navigate('/productos')}
                    style={{ marginTop: '20px' }}
                  >
                    Explorar productos
                  </button>
                </div>
              ) : (
                <div className="stack">
                  {history.map(transaction => (
                    <div 
                      key={transaction.id} 
                      className="card p"
                      style={{ 
                        background: transaction.type === 'earn' 
                          ? 'rgba(74, 222, 128, 0.05)' 
                          : 'rgba(248, 113, 113, 0.05)',
                        border: `1px solid ${transaction.type === 'earn' ? '#4ade80' : '#f87171'}`
                      }}
                    >
                      <div style={{ 
                        display: 'flex', 
                        justifyContent: 'space-between', 
                        alignItems: 'start',
                        marginBottom: '10px'
                      }}>
                        <div>
                          <div style={{ 
                            fontSize: '1.1em', 
                            fontWeight: '700',
                            color: transaction.type === 'earn' ? '#4ade80' : '#f87171'
                          }}>
                            {transaction.type === 'earn' ? '🎁 Puntos ganados' : '💰 Puntos canjeados'}
                          </div>
                          <div className="muted" style={{ fontSize: '0.85em', marginTop: '5px' }}>
                            {formatDate(transaction.date)}
                          </div>
                        </div>
                        <div style={{ 
                          fontSize: '1.8em', 
                          fontWeight: '700',
                          color: transaction.type === 'earn' ? '#4ade80' : '#f87171'
                        }}>
                          {transaction.points > 0 ? '+' : ''}{transaction.points}
                        </div>
                      </div>
                      
                      <div style={{ 
                        padding: '10px', 
                        background: 'rgba(0,0,0,0.2)', 
                        borderRadius: '6px'
                      }}>
                        <div style={{ fontSize: '0.9em', color: 'rgba(255,255,255,0.7)' }}>
                          {transaction.description}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default MisPuntos;
