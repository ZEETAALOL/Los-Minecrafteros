import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

function Blog() {
  const blogs = [
    {
      id: 1,
      titulo: 'Lanzamiento de la PS5 Pro',
      descripcion: 'Sony prepara una nueva versión con mejor rendimiento gráfico...',
      imagen: '/img/blog1.jpg'
    },
    {
      id: 2,
      titulo: 'Tips para armar tu PC Gamer',
      descripcion: 'Recomendaciones para un setup óptimo y accesible...',
      imagen: '/img/blog2.jpg'
    },
    {
      id: 3,
      titulo: 'Los mejores juegos indie de 2024',
      descripcion: 'Descubre las joyas ocultas del gaming independiente...',
      imagen: '/img/blog3.jpg'
    }
  ];

  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">Blog Gamer</h1>
        <p style={{textAlign: 'center', marginBottom: '30px', color: '#666'}}>
          Mantente actualizado con las últimas noticias y guías del mundo gamer
        </p>
        <div className="grid blogs">
          {blogs.map(blog => (
            <Link to={`/blog/${blog.id}`} key={blog.id} style={{textDecoration: 'none', color: 'inherit'}}>
              <article className="card" style={{cursor: 'pointer', transition: 'transform 0.3s ease, box-shadow 0.3s ease'}}>
                <div style={{
                  width: '100%',
                  height: '200px',
                  background: `linear-gradient(135deg, ${blog.id === 1 ? '#667eea, #764ba2' : blog.id === 2 ? '#f093fb, #f5576c' : '#4facfe, #00f2fe'})`,
                  borderRadius: '8px 8px 0 0',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '48px',
                  color: 'white'
                }}>
                  🎮
                </div>
                <div style={{padding: '20px'}}>
                  <h2 style={{marginBottom: '10px'}}>{blog.titulo}</h2>
                  <p style={{color: '#666', marginBottom: '15px'}}>{blog.descripcion}</p>
                  <span style={{color: '#ff6b6b', fontWeight: 'bold'}}>Leer más →</span>
                </div>
              </article>
            </Link>
          ))}
        </div>
      </main>

      <Footer />
    </>
  );
}

export default Blog;
