import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useCart } from '../hooks/useCart';
import { useSession, useProducts } from '../hooks/useLocalStorage';
import { useLoyaltyPoints } from '../hooks/useLoyaltyPoints';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

// Fix para iconos de Leaflet en React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

function LocationMarker({ position, setPosition }) {
  useMapEvents({
    click(e) {
      setPosition(e.latlng);
    },
  });

  return position === null ? null : <Marker position={position} />;
}

function Carrito() {
  const { groupedCart, setQuantity, removeFromCart, clearCart } = useCart();
  const { session } = useSession();
  const [products, setProducts] = useProducts();
  const { 
    getUserPoints, 
    addPointsFromPurchase, 
    redeemPoints, 
    getMaxDiscount,
    POINTS_TO_DISCOUNT 
  } = useLoyaltyPoints();
  const groups = groupedCart();

  const [shipping, setShipping] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('shippingAddress')) || {};
    } catch {
      return {};
    }
  });

  const [showMap, setShowMap] = useState(false);
  const [markerPosition, setMarkerPosition] = useState(null);
  const [pointsToRedeem, setPointsToRedeem] = useState(0);
  const [loyaltyDiscount, setLoyaltyDiscount] = useState(0);

  const duocDiscountRate = () => {
    const mail = session?.correo || '';
    return /@(duoc\.cl|profesor\.duoc\.cl)$/i.test(mail) ? 0.20 : 0;
  };

  const cartTotals = () => {
    const subtotal = groups.reduce((s, g) => s + g.precio * g.qty, 0);
    const duocRate = duocDiscountRate();
    const duocDiscount = Math.round(subtotal * duocRate);
    const subtotalAfterDuoc = subtotal - duocDiscount;
    const pointsDiscount = loyaltyDiscount;
    const total = Math.max(0, subtotalAfterDuoc - pointsDiscount);
    return { subtotal, duocRate, duocDiscount, pointsDiscount, total };
  };

  const totals = cartTotals();

  const userPoints = session ? getUserPoints(session.id) : 0;
  const maxRedeemableDiscount = session ? getMaxDiscount(session.id) : 0;
  const maxRedeemablePoints = Math.floor(maxRedeemableDiscount / 10000) * POINTS_TO_DISCOUNT;

  const handleShippingChange = (e) => {
    const { name, value } = e.target;
    setShipping(prev => ({ ...prev, [name]: value }));
  };

  const handleUsarPunto = () => {
    if (!markerPosition) {
      alert('Primero haz click en el mapa para colocar el punto.');
      return;
    }
    setShipping(prev => ({
      ...prev,
      lat: markerPosition.lat.toFixed(6),
      lng: markerPosition.lng.toFixed(6)
    }));
    setShowMap(false);
  };

  const handleRedeemPoints = () => {
    if (!session) {
      alert('Debes iniciar sesión para canjear puntos');
      return;
    }

    if (pointsToRedeem <= 0 || pointsToRedeem % POINTS_TO_DISCOUNT !== 0) {
      alert(`Los puntos deben ser múltiplos de ${POINTS_TO_DISCOUNT}`);
      return;
    }

    const result = redeemPoints(session.id, pointsToRedeem);
    
    if (result.success) {
      setLoyaltyDiscount(result.discountAmount);
      alert(result.message);
    } else {
      alert(result.message);
    }
  };

  const handleClearLoyaltyDiscount = () => {
    setLoyaltyDiscount(0);
    setPointsToRedeem(0);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!shipping.direccion) {
      alert('Indica tu dirección de envío.');
      return;
    }
    if (!(shipping.lat && shipping.lng)) {
      alert('Por favor selecciona el punto exacto en el mapa.');
      return;
    }
    
    // Descontar stock de los productos comprados
    const updatedProducts = products.map(product => {
      const itemInCart = groups.find(g => g.id === product.id);
      if (itemInCart) {
        const newStock = product.stock - itemInCart.qty;
        // Asegurarse que el stock no sea negativo
        return {
          ...product,
          stock: Math.max(0, newStock)
        };
      }
      return product;
    });
    
    // Verificar si hay productos sin stock suficiente
    const insufficientStock = groups.some(item => {
      const product = products.find(p => p.id === item.id);
      return product && product.stock < item.qty;
    });
    
    if (insufficientStock) {
      alert('⚠️ Algunos productos no tienen stock suficiente. Por favor revisa tu carrito.');
      return;
    }
    
    // Actualizar productos en localStorage
    setProducts(updatedProducts);
    
    localStorage.setItem('shippingAddress', JSON.stringify(shipping));
    
    // Agregar puntos de fidelidad si el usuario está logueado
    if (session) {
      const pointsEarned = addPointsFromPurchase(session.id, totals.total);
      alert(`¡Compra confirmada! 🛒\n\nStock actualizado correctamente.\nHas ganado ${pointsEarned} puntos de fidelidad.\nPuntos totales: ${getUserPoints(session.id) + pointsEarned}`);
    } else {
      alert('¡Compra confirmada! Stock actualizado. Gracias por tu pedido 🛒');
    }
    
    clearCart();
    setShipping({});
    setLoyaltyDiscount(0);
    setPointsToRedeem(0);
  };

  if (groups.length === 0) {
    return (
      <>
        <Header />
        <main className="section">
          <h1 className="section-title">Tu carrito</h1>
          <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
            <p>Tu carrito está vacío.</p>
            <a href="/productos" className="btn-primary" style={{ marginTop: '20px', display: 'inline-block' }}>
              Ir al catálogo
            </a>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">Tu carrito</h1>
        <div className="grid" style={{ gridTemplateColumns: '2fr 1fr', gap: '20px' }}>
          <div className="stack">
            {groups.map(g => (
              <div key={g.id} className="card p" style={{ display: 'grid', gridTemplateColumns: '1fr auto', alignItems: 'center', gap: '12px' }}>
                <div>
                  <div><strong>{g.nombre}</strong></div>
                  <div className="muted">ID {g.id}</div>
                  <div>{CLP.format(g.precio)} c/u</div>
                </div>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <label className="muted">Cantidad</label>
                  <input 
                    type="number" 
                    min="0" 
                    value={g.qty} 
                    onChange={(e) => setQuantity(g.id, e.target.value)}
                    style={{ width: '80px', padding: '8px', borderRadius: '6px', border: '1px solid #333', background: '#222', color: '#fff' }} 
                  />
                  <button className="btn-secondary" onClick={() => removeFromCart(g.id)}>Quitar uno</button>
                </div>
              </div>
            ))}
          </div>

          <aside className="card p">
            <h3>Resumen</h3>
            <div className="stack">
              <div className="line"><span>Subtotal</span><strong>{CLP.format(totals.subtotal)}</strong></div>
              <div className="line"><span>Descuento {totals.duocRate > 0 ? '(DUOC 20%)' : ''}</span><strong>-{CLP.format(totals.duocDiscount)}</strong></div>
              {totals.pointsDiscount > 0 && (
                <div className="line" style={{ color: '#00d4ff' }}>
                  <span>Descuento por puntos</span>
                  <strong>-{CLP.format(totals.pointsDiscount)}</strong>
                </div>
              )}
              <div className="line total"><span>Total</span><strong>{CLP.format(totals.total)}</strong></div>
            </div>

            {/* Sistema de puntos de fidelidad */}
            {session && (
              <>
                <hr />
                <h3>💎 Puntos de Fidelidad</h3>
                <div className="card p" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none' }}>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '2.5em', fontWeight: '700', color: '#fff' }}>
                      {userPoints}
                    </div>
                    <div style={{ color: 'rgba(255,255,255,0.9)', fontSize: '0.9em' }}>
                      puntos disponibles
                    </div>
                  </div>
                </div>

                {userPoints >= POINTS_TO_DISCOUNT && (
                  <div className="stack" style={{ marginTop: '15px' }}>
                    <p style={{ fontSize: '0.9em', color: 'rgba(255,255,255,0.7)' }}>
                      Puedes canjear tus puntos por descuentos:<br />
                      <strong>{POINTS_TO_DISCOUNT} puntos = $10.000 descuento</strong>
                    </p>
                    
                    {loyaltyDiscount === 0 ? (
                      <>
                        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                          <input 
                            type="number" 
                            min="0" 
                            max={maxRedeemablePoints}
                            step={POINTS_TO_DISCOUNT}
                            value={pointsToRedeem}
                            onChange={(e) => setPointsToRedeem(Math.min(parseInt(e.target.value) || 0, maxRedeemablePoints))}
                            placeholder="Puntos a canjear"
                            style={{ flex: 1, padding: '10px', borderRadius: '8px', border: '1px solid #333', background: '#222', color: '#fff' }}
                          />
                          <button 
                            className="btn-primary" 
                            onClick={handleRedeemPoints}
                            disabled={pointsToRedeem < POINTS_TO_DISCOUNT}
                          >
                            Canjear
                          </button>
                        </div>
                        <p style={{ fontSize: '0.85em', color: 'rgba(255,255,255,0.5)', marginTop: '5px' }}>
                          Máximo: {maxRedeemablePoints} pts = {CLP.format(maxRedeemableDiscount)}
                        </p>
                      </>
                    ) : (
                      <div className="card p" style={{ background: 'rgba(0, 212, 255, 0.1)', border: '1px solid #00d4ff' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span>
                            ✅ Descuento aplicado: {CLP.format(loyaltyDiscount)}
                          </span>
                          <button 
                            className="btn-secondary" 
                            onClick={handleClearLoyaltyDiscount}
                            style={{ padding: '5px 10px', fontSize: '0.85em' }}
                          >
                            Cancelar
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div style={{ marginTop: '15px', padding: '10px', background: 'rgba(0, 212, 255, 0.1)', borderRadius: '8px', fontSize: '0.85em' }}>
                  <strong>💡 ¿Cómo gano puntos?</strong>
                  <ul style={{ marginLeft: '20px', marginTop: '5px', color: 'rgba(255,255,255,0.7)' }}>
                    <li>Ganas 1 punto por cada $1.000 gastados</li>
                    <li>Los puntos se acumulan automáticamente</li>
                    <li>Canjea 100 puntos por $10.000 de descuento</li>
                  </ul>
                  <p style={{ marginTop: '10px', color: '#00d4ff' }}>
                    Con esta compra ganarás {Math.floor(totals.total / 1000)} puntos
                  </p>
                </div>
              </>
            )}
            
            <hr />
            
            <h3>Envío</h3>
            <form onSubmit={handleSubmit} className="stack">
              <input 
                name="nombre" 
                placeholder="Nombre de quien recibe" 
                value={shipping.nombre || ''} 
                onChange={handleShippingChange}
                maxLength="100" 
                required 
              />
              <input 
                name="direccion" 
                placeholder="Dirección (calle y número)" 
                value={shipping.direccion || ''} 
                onChange={handleShippingChange}
                maxLength="300" 
                required 
              />

              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <button className="btn-secondary" type="button" onClick={() => setShowMap(!showMap)}>
                  {showMap ? 'Cerrar mapa' : 'Elegir en el mapa'}
                </button>
                <span className="muted">Click en el mapa para marcar</span>
              </div>

              {showMap && (
                <div className="card p" style={{ marginTop: '10px' }}>
                  <MapContainer 
                    center={[-33.45, -70.6667]} 
                    zoom={12} 
                    style={{ height: '320px', borderRadius: '12px', zIndex: 1 }}
                  >
                    <TileLayer
                      attribution='&copy; OpenStreetMap'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <LocationMarker position={markerPosition} setPosition={setMarkerPosition} />
                  </MapContainer>
                  <div className="muted" style={{ marginTop: '8px' }}>
                    Click en el mapa para marcar. Luego presiona "Usar este punto".
                  </div>
                  <button className="btn-primary" type="button" onClick={handleUsarPunto} style={{ marginTop: '8px' }}>
                    Usar este punto
                  </button>
                </div>
              )}

              <input type="hidden" name="lat" value={shipping.lat || ''} />
              <input type="hidden" name="lng" value={shipping.lng || ''} />

              {shipping.lat && shipping.lng && (
                <div style={{ marginTop: '10px' }}>
                  <table className="table">
                    <caption>Dirección seleccionada</caption>
                    <tbody>
                      <tr><th>Dirección</th><td>{shipping.direccion}</td></tr>
                      <tr><th>Coordenadas</th><td>{shipping.lat}, {shipping.lng}</td></tr>
                    </tbody>
                  </table>

                  <table className="table" style={{ marginTop: '10px' }}>
                    <caption>Información extra (opcional)</caption>
                    <tbody>
                      <tr>
                        <th>Departamento</th>
                        <td><input name="depto" value={shipping.depto || ''} onChange={handleShippingChange} placeholder="Ej: Torre B, 1204" /></td>
                      </tr>
                      <tr>
                        <th>Casa</th>
                        <td><input name="casa" value={shipping.casa || ''} onChange={handleShippingChange} placeholder="Ej: Pasaje Z, N° 45" /></td>
                      </tr>
                      <tr>
                        <th>Quien recibe</th>
                        <td><input name="receptor" value={shipping.receptor || ''} onChange={handleShippingChange} placeholder="Nombre" /></td>
                      </tr>
                      <tr>
                        <th>Comuna</th>
                        <td><input name="comuna" value={shipping.comuna || ''} onChange={handleShippingChange} /></td>
                      </tr>
                      <tr>
                        <th>Región</th>
                        <td><input name="region" value={shipping.region || ''} onChange={handleShippingChange} /></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              <button className="btn-primary" type="submit" style={{ marginTop: '10px' }}>Confirmar y pagar</button>
            </form>
            <p className="muted" style={{ marginTop: '10px' }}>
              * Si iniciaste sesión con correo institucional DUOC, se aplica 20% OFF automáticamente.
            </p>
          </aside>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default Carrito;
