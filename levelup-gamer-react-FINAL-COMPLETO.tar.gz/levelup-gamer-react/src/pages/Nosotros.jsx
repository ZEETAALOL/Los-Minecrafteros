import Header from '../components/Header';
import Footer from '../components/Footer';

function Nosotros() {
  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">Sobre Nosotros</h1>
        <div className="card" style={{maxWidth: '800px', margin: '0 auto', textAlign: 'left'}}>
          <p style={{marginBottom: '20px'}}>
            Somos <strong>Level-Up Gamer</strong>, una tienda online creada para los amantes del gaming en Chile. 
            Nuestra misión es ofrecer productos de calidad y apoyar la comunidad gamer.
          </p>
        </div>

        <h2 className="section-title" style={{marginTop: '40px'}}>Equipo</h2>
        <div className="grid team">
          <div className="card">
            <div style={{
              width: '150px',
              height: '150px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              margin: '0 auto 15px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '48px',
              fontWeight: 'bold',
              color: 'white'
            }}>
              BM
            </div>
            <h3>Bastian Martinez</h3>
            <p>Desarrollador Backend/Frontend</p>
            <p style={{fontSize: '0.9em', color: '#666'}}>Especialista en React y Node.js</p>
          </div>
          <div className="card">
            <div style={{
              width: '150px',
              height: '150px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
              margin: '0 auto 15px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '48px',
              fontWeight: 'bold',
              color: 'white'
            }}>
              BP
            </div>
            <h3>Benjamin Palma</h3>
            <p>Desarrollador Backend/Frontend</p>
            <p style={{fontSize: '0.9em', color: '#666'}}>Experto en UI/UX y JavaScript</p>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}

export default Nosotros;
