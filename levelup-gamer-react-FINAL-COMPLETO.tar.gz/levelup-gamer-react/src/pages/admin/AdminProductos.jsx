import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminHeader from '../../components/AdminHeader';
import { useProducts } from '../../hooks/useLocalStorage';
import { useSession } from '../../hooks/useLocalStorage';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function AdminProductos() {
  const { session } = useSession();
  const navigate = useNavigate();
  const [products, setProducts] = useProducts();

  const [formData, setFormData] = useState({
    id: '',
    codigo: '',
    nombre: '',
    descripcion: '',
    precio: '',
    stock: '',
    stockCritico: '',
    categoria: '',
    img: ''
  });

  useEffect(() => {
    if (!session || !['Administrador', 'Vendedor'].includes(session.tipo)) {
      alert('Acceso restringido. Inicia sesión con perfil autorizado.');
      navigate('/login');
    }
  }, [session, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const limpiarForm = () => {
    setFormData({
      id: '',
      codigo: '',
      nombre: '',
      descripcion: '',
      precio: '',
      stock: '',
      stockCritico: '',
      categoria: '',
      img: ''
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { codigo, nombre, descripcion, precio, stock, stockCritico, categoria, img, id } = formData;

    // Validaciones
    if (codigo.length < 3) {
      alert('Código: mínimo 3 caracteres');
      return;
    }

    if (nombre.length === 0 || nombre.length > 100) {
      alert('Nombre requerido (max 100)');
      return;
    }

    if (descripcion.length > 500) {
      alert('Descripción excede 500 caracteres');
      return;
    }

    const precioNum = parseFloat(precio);
    if (!(precioNum >= 0)) {
      alert('Precio debe ser ≥ 0');
      return;
    }

    const stockNum = parseInt(stock, 10);
    if (!(Number.isInteger(stockNum) && stockNum >= 0)) {
      alert('Stock entero ≥ 0');
      return;
    }

    const stockCriticoNum = stockCritico === '' ? null : parseInt(stockCritico, 10);
    if (stockCriticoNum !== null && !(Number.isInteger(stockCriticoNum) && stockCriticoNum >= 0)) {
      alert('Stock crítico entero ≥ 0');
      return;
    }

    if (!categoria) {
      alert('Selecciona categoría');
      return;
    }

    const isEdit = Boolean(id);
    const existsCodigo = products.some(
      x => x.codigo.toLowerCase() === codigo.toLowerCase() && (!isEdit || x.id !== parseInt(id, 10))
    );
    if (existsCodigo) {
      alert('Código de producto ya existe');
      return;
    }

    if (isEdit) {
      // Editar
      const idx = products.findIndex(x => x.id === parseInt(id, 10));
      if (idx >= 0) {
        const updated = [...products];
        updated[idx] = {
          ...updated[idx],
          codigo,
          nombre,
          descripcion,
          precio: precioNum,
          stock: stockNum,
          stockCritico: stockCriticoNum,
          categoria,
          img
        };
        setProducts(updated);
      }
    } else {
      // Nuevo
      const newId = (products[products.length - 1]?.id || 0) + 1;
      setProducts([...products, {
        id: newId,
        codigo,
        nombre,
        descripcion,
        precio: precioNum,
        stock: stockNum,
        stockCritico: stockCriticoNum,
        categoria,
        img
      }]);
    }

    alert('✅ Producto guardado');
    limpiarForm();
  };

  const handleEditar = (product) => {
    setFormData({
      id: product.id,
      codigo: product.codigo,
      nombre: product.nombre,
      descripcion: product.descripcion || '',
      precio: product.precio,
      stock: product.stock,
      stockCritico: product.stockCritico ?? '',
      categoria: product.categoria,
      img: product.img || ''
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEliminar = (id) => {
    if (window.confirm('¿Eliminar producto?')) {
      setProducts(products.filter(x => x.id !== id));
    }
  };

  if (!session) return null;

  return (
    <div className="admin">
      <AdminHeader />
      <main className="section">
        <form onSubmit={handleSubmit} className="form-card" style={{maxWidth: '900px', margin: '0 auto'}}>
          <h2>{formData.id ? '✏️ Editar Producto' : '➕ Nuevo Producto'}</h2>
          
          {formData.id && (
            <div style={{
              background: 'rgba(189, 46, 255, 0.1)',
              padding: '12px',
              borderRadius: '8px',
              marginBottom: '10px',
              border: '2px solid var(--primary)',
              textAlign: 'center',
              fontWeight: 'bold'
            }}>
              🔧 Editando: {formData.nombre} (ID: {formData.id})
            </div>
          )}

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '20px'
          }}>
            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: 'var(--primary)',
                fontSize: '0.95em'
              }}>
                📝 Código del Producto *
              </label>
              <input 
                name="codigo" 
                placeholder="Ej: CO001, JM003" 
                value={formData.codigo} 
                onChange={handleChange} 
                required 
                style={{width: '100%'}}
              />
              <small style={{color: 'rgba(255,255,255,0.6)', fontSize: '0.85em'}}>
                Mínimo 3 caracteres, único
              </small>
            </div>

            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: 'var(--primary)',
                fontSize: '0.95em'
              }}>
                🏷️ Nombre del Producto *
              </label>
              <input 
                name="nombre" 
                placeholder="Ej: PlayStation 5" 
                value={formData.nombre} 
                onChange={handleChange} 
                maxLength="100" 
                required 
                style={{width: '100%'}}
              />
              <small style={{color: 'rgba(255,255,255,0.6)', fontSize: '0.85em'}}>
                Máximo 100 caracteres
              </small>
            </div>
          </div>

          <div>
            <label style={{
              display: 'block',
              marginBottom: '8px',
              fontWeight: '600',
              color: 'var(--primary)',
              fontSize: '0.95em'
            }}>
              📄 Descripción
            </label>
            <textarea 
              name="descripcion" 
              placeholder="Describe las características del producto..." 
              value={formData.descripcion} 
              onChange={handleChange} 
              maxLength="500"
              rows="3"
              style={{width: '100%'}}
            />
            <small style={{color: 'rgba(255,255,255,0.6)', fontSize: '0.85em'}}>
              Opcional, máximo 500 caracteres
            </small>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '20px',
            background: 'rgba(0, 212, 255, 0.05)',
            padding: '20px',
            borderRadius: '12px',
            border: '2px solid rgba(0, 212, 255, 0.3)'
          }}>
            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: 'var(--accent-2)',
                fontSize: '0.95em'
              }}>
                💰 Precio (CLP) *
              </label>
              <input 
                name="precio" 
                type="number" 
                placeholder="99990" 
                value={formData.precio} 
                onChange={handleChange} 
                min="0" 
                step="10" 
                required 
                style={{width: '100%'}}
              />
              <small style={{color: 'rgba(255,255,255,0.6)', fontSize: '0.85em'}}>
                En pesos chilenos
              </small>
            </div>

            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: 'var(--accent-2)',
                fontSize: '0.95em'
              }}>
                📦 Stock Disponible *
              </label>
              <input 
                name="stock" 
                type="number" 
                placeholder="10" 
                value={formData.stock} 
                onChange={handleChange} 
                min="0" 
                step="1" 
                required 
                style={{width: '100%'}}
              />
              <small style={{color: 'rgba(255,255,255,0.6)', fontSize: '0.85em'}}>
                Cantidad en inventario
              </small>
            </div>

            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: '#f39c12',
                fontSize: '0.95em'
              }}>
                ⚠️ Stock Crítico
              </label>
              <input 
                name="stockCritico" 
                type="number" 
                placeholder="2" 
                value={formData.stockCritico} 
                onChange={handleChange} 
                min="0" 
                step="1" 
                style={{width: '100%'}}
              />
              <small style={{color: 'rgba(255,255,255,0.6)', fontSize: '0.85em'}}>
                Alerta cuando stock ≤ este valor
              </small>
            </div>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '20px'
          }}>
            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: 'var(--primary)',
                fontSize: '0.95em'
              }}>
                🗂️ Categoría *
              </label>
              <select 
                name="categoria" 
                value={formData.categoria} 
                onChange={handleChange} 
                required
                style={{width: '100%'}}
              >
                <option value="">-- Selecciona una categoría --</option>
                <option>Consolas</option>
                <option>Accesorios</option>
                <option>Juegos de Mesa</option>
                <option>Sillas Gamers</option>
                <option>PC Gamer</option>
                <option>Ropa Gamer</option>
              </select>
            </div>

            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '600',
                color: 'var(--primary)',
                fontSize: '0.95em'
              }}>
                🖼️ URL de Imagen
              </label>
              <input 
                name="img" 
                placeholder="https://ejemplo.com/imagen.jpg o /img/producto.jpg" 
                value={formData.img} 
                onChange={handleChange}
                style={{width: '100%'}}
              />
              <small style={{color: 'rgba(255,255,255,0.6)', fontSize: '0.85em'}}>
                Opcional, URL completa o ruta local
              </small>
            </div>
          </div>

          <div className="actions" style={{
            display: 'flex',
            gap: '15px',
            marginTop: '10px'
          }}>
            <button type="submit" className="btn-primary" style={{flex: 1}}>
              {formData.id ? '💾 Actualizar Producto' : '➕ Crear Producto'}
            </button>
            <button 
              type="button" 
              className="btn-secondary" 
              onClick={limpiarForm}
              style={{flex: 1}}
            >
              🔄 Limpiar Formulario
            </button>
          </div>
        </form>

        <h2 className="section-title" style={{marginTop: '60px'}}>📋 Listado de Productos</h2>
        
        <div style={{
          background: 'rgba(26, 26, 36, 0.8)',
          padding: '20px',
          borderRadius: '12px',
          border: '1px solid rgba(189, 46, 255, 0.3)',
          marginBottom: '20px'
        }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '20px',
            textAlign: 'center'
          }}>
            <div>
              <div style={{fontSize: '2em', marginBottom: '5px'}}>📦</div>
              <div style={{color: 'var(--accent-2)', fontSize: '1.5em', fontWeight: 'bold'}}>
                {products.length}
              </div>
              <div style={{color: 'rgba(255,255,255,0.7)', fontSize: '0.9em'}}>Total Productos</div>
            </div>
            <div>
              <div style={{fontSize: '2em', marginBottom: '5px'}}>✅</div>
              <div style={{color: '#2ecc71', fontSize: '1.5em', fontWeight: 'bold'}}>
                {products.filter(p => p.stock > (p.stockCritico || 0)).length}
              </div>
              <div style={{color: 'rgba(255,255,255,0.7)', fontSize: '0.9em'}}>Con Stock Normal</div>
            </div>
            <div>
              <div style={{fontSize: '2em', marginBottom: '5px'}}>⚠️</div>
              <div style={{color: '#f39c12', fontSize: '1.5em', fontWeight: 'bold'}}>
                {products.filter(p => p.stockCritico != null && p.stock <= p.stockCritico && p.stock > 0).length}
              </div>
              <div style={{color: 'rgba(255,255,255,0.7)', fontSize: '0.9em'}}>Stock Crítico</div>
            </div>
            <div>
              <div style={{fontSize: '2em', marginBottom: '5px'}}>❌</div>
              <div style={{color: '#e74c3c', fontSize: '1.5em', fontWeight: 'bold'}}>
                {products.filter(p => p.stock === 0).length}
              </div>
              <div style={{color: 'rgba(255,255,255,0.7)', fontSize: '0.9em'}}>Sin Stock</div>
            </div>
          </div>
        </div>

        <div style={{overflowX: 'auto'}}>
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>💰 Precio</th>
                <th>📦 Stock</th>
                <th>⚠️ Crítico</th>
                <th>Categoría</th>
                <th>Img</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {products.map(p => (
                <tr key={p.id} style={{
                  background: p.stock === 0 ? 'rgba(231, 76, 60, 0.1)' : 
                              (p.stockCritico != null && p.stock <= p.stockCritico) ? 'rgba(243, 156, 18, 0.1)' : 
                              'transparent'
                }}>
                  <td>{p.id}</td>
                  <td><strong>{p.codigo}</strong></td>
                  <td>{p.nombre}</td>
                  <td style={{color: 'var(--accent-2)', fontWeight: 'bold'}}>
                    {CLP.format(p.precio)}
                  </td>
                  <td style={{textAlign: 'center'}}>
                    <span style={{
                      display: 'inline-block',
                      padding: '4px 10px',
                      borderRadius: '6px',
                      background: p.stock === 0 ? '#e74c3c' : 
                                  (p.stockCritico != null && p.stock <= p.stockCritico) ? '#f39c12' : 
                                  '#2ecc71',
                      color: '#fff',
                      fontWeight: 'bold'
                    }}>
                      {p.stock}
                    </span>
                  </td>
                  <td style={{textAlign: 'center'}}>
                    {p.stockCritico != null ? p.stockCritico : '-'}
                  </td>
                  <td>
                    <span style={{
                      padding: '4px 8px',
                      borderRadius: '6px',
                      background: 'rgba(189, 46, 255, 0.2)',
                      fontSize: '0.85em'
                    }}>
                      {p.categoria}
                    </span>
                  </td>
                  <td>{p.img ? <a href={p.img} target="_blank" rel="noopener noreferrer" style={{color: 'var(--accent-2)'}}>🔗 Ver</a> : '-'}</td>
                  <td>
                    <div style={{display: 'flex', gap: '5px', flexWrap: 'wrap'}}>
                      <button 
                        onClick={() => handleEditar(p)}
                        style={{
                          background: 'var(--primary)',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        ✏️ Editar
                      </button>
                      <button 
                        onClick={() => handleEliminar(p.id)}
                        style={{
                          background: '#e74c3c',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        🗑️ Eliminar
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}

export default AdminProductos;
