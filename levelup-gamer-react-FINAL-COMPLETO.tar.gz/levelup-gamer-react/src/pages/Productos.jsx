import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useProducts } from '../hooks/useLocalStorage';
import { useCart } from '../hooks/useCart';
import { useReviews } from '../hooks/useReviews';

const CLP = new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' });

function Productos() {
  const [products] = useProducts();
  const { addToCart } = useCart();
  const { getProductRating, getProductReviews } = useReviews();
  const location = useLocation();
  const navigate = useNavigate();
  
  const [busqueda, setBusqueda] = useState('');
  const [categoria, setCategoria] = useState('');
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [loading, setLoading] = useState(false);

  // Detectar categoría desde hash (#Accesorios)
  useEffect(() => {
    const hashCat = decodeURIComponent((location.hash || '').slice(1));
    if (hashCat) {
      setCategoria(hashCat);
    }
  }, [location.hash]);

  // Filtrar productos con delay simulado para mostrar animación
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      let result = products;
      
      if (busqueda) {
        result = result.filter(p => 
          p.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
          p.descripcion.toLowerCase().includes(busqueda.toLowerCase())
        );
      }
      
      if (categoria) {
        result = result.filter(p => p.categoria === categoria);
      }
      
      setFilteredProducts(result);
      setLoading(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [busqueda, categoria, products]);

  const handleAddToCart = (product) => {
    addToCart(product);
    
    // Animación de feedback visual
    const button = event.target;
    button.style.transform = 'scale(0.95)';
    setTimeout(() => {
      button.style.transform = 'scale(1)';
    }, 100);
    
    alert('✅ Producto añadido al carrito');
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span
          key={i}
          style={{
            color: i <= rating ? '#FFD700' : '#555',
            fontSize: '1em'
          }}
        >
          ★
        </span>
      );
    }
    return stars;
  };

  const handleViewDetails = (productId) => {
    navigate(`/producto?id=${productId}`);
  };

  const categorias = [
    'Todas las categorías',
    'Consolas',
    'Accesorios',
    'Juegos de Mesa',
    'Sillas Gamers',
    'PC Gamer',
    'Ropa Gamer'
  ];

  return (
    <>
      <Header />
      
      <main className="section">
        <h1 className="section-title">🎮 Catálogo de Productos</h1>
        
        <div className="filters">
          <input 
            type="text" 
            placeholder="🔍 Buscar producto..." 
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            style={{ flex: 2 }}
          />
          <select 
            value={categoria} 
            onChange={(e) => setCategoria(e.target.value === 'Todas las categorías' ? '' : e.target.value)}
            style={{ flex: 1 }}
          >
            {categorias.map(cat => (
              <option key={cat} value={cat === 'Todas las categorías' ? '' : cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* Contador de productos */}
        <div style={{ 
          textAlign: 'center', 
          margin: '20px 0', 
          color: 'rgba(255,255,255,0.7)',
          fontSize: '1.1em' 
        }}>
          {loading ? (
            <span>⏳ Cargando...</span>
          ) : (
            <span>📦 Mostrando <strong style={{ color: '#00d4ff' }}>{filteredProducts.length}</strong> productos</span>
          )}
        </div>

        {loading ? (
          <div style={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center', 
            minHeight: '400px' 
          }}>
            <div style={{ 
              fontSize: '3em', 
              animation: 'spin 1s linear infinite' 
            }}>⚙️</div>
          </div>
        ) : (
          <div className="grid cards">
            {filteredProducts.map((p, index) => {
              const stockWarn = (p.stockCritico != null && p.stock <= p.stockCritico) 
                ? <span className="hint">⚠️ ¡Últimas unidades!</span> 
                : p.stock < 10 
                  ? <span style={{ color: '#ffaa00', fontSize: '0.9em' }}>🔥 Stock limitado</span>
                  : null;

              const avgRating = getProductRating(p.id);
              const reviewCount = getProductReviews(p.id).length;
                
              return (
                <div key={p.id} className="card" style={{ '--delay': index % 12 }}>
                  <div 
                    style={{ position: 'relative', cursor: 'pointer' }}
                    onClick={() => handleViewDetails(p.id)}
                  >
                    <img loading="lazy" src={p.img} alt={p.nombre} />
                    {p.stock <= p.stockCritico && (
                      <span style={{
                        position: 'absolute',
                        top: '10px',
                        right: '10px',
                        background: 'rgba(255, 0, 0, 0.9)',
                        color: '#fff',
                        padding: '5px 10px',
                        borderRadius: '8px',
                        fontSize: '0.8em',
                        fontWeight: '700'
                      }}>
                        ⚠️ STOCK BAJO
                      </span>
                    )}
                  </div>
                  <h3 
                    style={{ cursor: 'pointer' }}
                    onClick={() => handleViewDetails(p.id)}
                  >
                    {p.nombre}
                  </h3>

                  {/* Rating */}
                  {reviewCount > 0 && (
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      gap: '8px',
                      margin: '10px 0'
                    }}>
                      <div style={{ display: 'flex', gap: '2px' }}>
                        {renderStars(Math.round(avgRating))}
                      </div>
                      <span style={{ fontSize: '0.9em', fontWeight: '700', color: '#FFD700' }}>
                        {avgRating}
                      </span>
                      <span className="muted" style={{ fontSize: '0.85em' }}>
                        ({reviewCount})
                      </span>
                    </div>
                  )}

                  <p style={{ 
                    color: 'rgba(255,255,255,0.6)', 
                    fontSize: '0.9em', 
                    minHeight: '60px',
                    margin: '10px 0' 
                  }}>
                    {p.descripcion}
                  </p>
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    margin: '10px 0' 
                  }}>
                    <span style={{ fontSize: '1.3em', fontWeight: '700', color: '#00d4ff' }}>
                      {CLP.format(p.precio)}
                    </span>
                    <span style={{ fontSize: '0.9em', color: 'rgba(255,255,255,0.6)' }}>
                      Stock: {p.stock}
                    </span>
                  </div>
                  {stockWarn}
                  <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                    <button 
                      className="btn-primary" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddToCart(p);
                      }}
                      style={{ flex: 1 }}
                    >
                      🛒 Añadir
                    </button>
                    <button 
                      className="btn-secondary" 
                      onClick={() => handleViewDetails(p.id)}
                      style={{ padding: '10px 20px' }}
                    >
                      Ver más
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        
        {!loading && filteredProducts.length === 0 && (
          <div className="card" style={{ 
            textAlign: 'center', 
            padding: '60px 40px',
            maxWidth: '600px',
            margin: '40px auto' 
          }}>
            <div style={{ fontSize: '4em', marginBottom: '20px' }}>😕</div>
            <h3>No se encontraron productos</h3>
            <p style={{ color: 'rgba(255,255,255,0.6)', margin: '20px 0' }}>
              Intenta ajustar los filtros o buscar otro término
            </p>
            <button 
              className="btn-primary" 
              onClick={() => { setBusqueda(''); setCategoria(''); }}
              style={{ marginTop: '20px' }}
            >
              🔄 Limpiar filtros
            </button>
          </div>
        )}
      </main>

      <Footer />
      
      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </>
  );
}

export default Productos;
