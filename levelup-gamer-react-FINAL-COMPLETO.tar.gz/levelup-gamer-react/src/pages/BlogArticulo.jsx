import { useParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

function BlogArticulo() {
  const { id } = useParams();

  const articulos = {
    '1': {
      titulo: 'Lanzamiento de la PS5 Pro',
      fecha: '20 de Octubre, 2024',
      autor: 'Bastian Martinez',
      contenido: `
        <h2>Una nueva era para PlayStation</h2>
        <p>
          Sony ha confirmado oficialmente el lanzamiento de la <strong>PlayStation 5 Pro</strong>, 
          la versión mejorada de su consola de última generación que promete revolucionar 
          la experiencia gaming con mejoras significativas en rendimiento y capacidades gráficas.
        </p>

        <h3>Especificaciones técnicas destacadas</h3>
        <p>
          La PS5 Pro incluye un GPU mejorado con hasta un 45% más de rendimiento en 
          comparación con la PS5 estándar, permitiendo jugar títulos AAA en resolución 
          4K nativa a 60 FPS de manera consistente. Además, incorpora tecnología de 
          Ray Tracing avanzada que ofrece reflejos y sombras más realistas.
        </p>

        <h3>Precio y disponibilidad</h3>
        <p>
          La consola estará disponible en Chile a partir de noviembre de 2024 con un 
          precio estimado de $699.990 CLP. Level-Up Gamer será uno de los distribuidores 
          oficiales, ofreciendo promociones de lanzamiento para los primeros compradores.
        </p>

        <h3>¿Vale la pena la actualización?</h3>
        <p>
          Si eres un jugador que busca la mejor experiencia visual y cuentas con un 
          televisor 4K o superior, la PS5 Pro es una inversión que vale la pena. 
          Sin embargo, la PS5 estándar sigue siendo una excelente opción para la 
          mayoría de los jugadores casuales.
        </p>

        <h3>Juegos optimizados</h3>
        <p>
          Títulos como Spider-Man 2, God of War Ragnarök y Horizon Forbidden West 
          recibirán parches de actualización gratuitos para aprovechar al máximo 
          el hardware de la PS5 Pro, con mejoras en texturas, framerate y efectos visuales.
        </p>
      `,
      categoria: 'Consolas',
      imagen: '🎮'
    },
    '2': {
      titulo: 'Tips para armar tu PC Gamer',
      fecha: '15 de Octubre, 2024',
      autor: 'Benjamin Palma',
      contenido: `
        <h2>Guía completa para construir tu primer PC Gamer</h2>
        <p>
          Armar tu propia PC gamer puede parecer intimidante al principio, pero con la 
          información correcta y un poco de paciencia, es una experiencia gratificante 
          que te permitirá obtener el mejor rendimiento por tu dinero.
        </p>

        <h3>1. Define tu presupuesto</h3>
        <p>
          Antes de comprar componentes, establece un presupuesto realista. En 2024, 
          puedes armar una PC gamer de entrada por alrededor de $500.000 CLP, mientras 
          que un setup de gama media-alta puede costar entre $1.000.000 y $1.500.000 CLP.
        </p>

        <h3>2. Componentes esenciales</h3>
        <ul>
          <li><strong>Procesador (CPU):</strong> AMD Ryzen 5 7600X o Intel Core i5-13600K son excelentes opciones</li>
          <li><strong>Tarjeta gráfica (GPU):</strong> NVIDIA RTX 4060 o AMD RX 7600 para 1080p gaming</li>
          <li><strong>Memoria RAM:</strong> Mínimo 16GB DDR4/DDR5 a 3200MHz o superior</li>
          <li><strong>Almacenamiento:</strong> SSD NVMe de 500GB para el sistema y juegos principales</li>
          <li><strong>Fuente de poder:</strong> Mínimo 650W certificación 80+ Bronze</li>
        </ul>

        <h3>3. Compatibilidad es clave</h3>
        <p>
          Asegúrate de que tu placa madre sea compatible con tu procesador (socket correcto) 
          y que tu gabinete tenga espacio suficiente para tu tarjeta gráfica. Usa herramientas 
          como PCPartPicker para verificar compatibilidad.
        </p>

        <h3>4. No escatimes en la fuente de poder</h3>
        <p>
          Una fuente de poder de calidad es crucial para la estabilidad del sistema. 
          Marcas confiables como Corsair, EVGA o Seasonic ofrecen garantías de 5-10 años 
          y protección para tus componentes.
        </p>

        <h3>5. Refrigeración adecuada</h3>
        <p>
          El cooler incluido con tu procesador suele ser suficiente, pero si planeas 
          hacer overclock o vives en una zona cálida, considera invertir en un cooler 
          aftermarket o un sistema de refrigeración líquida AIO.
        </p>

        <h3>Conclusión</h3>
        <p>
          Armar tu propia PC no solo es más económico, sino que también te da control 
          total sobre los componentes y facilita futuras actualizaciones. ¡En Level-Up Gamer 
          tenemos todos los componentes que necesitas!
        </p>
      `,
      categoria: 'Hardware',
      imagen: '💻'
    },
    '3': {
      titulo: 'Los mejores juegos indie de 2024',
      fecha: '10 de Octubre, 2024',
      autor: 'Bastian Martinez',
      contenido: `
        <h2>Joyas ocultas del gaming independiente</h2>
        <p>
          El 2024 ha sido un año excepcional para los juegos indie, con títulos innovadores 
          que han capturado la imaginación de jugadores en todo el mundo. Aquí te presentamos 
          nuestras recomendaciones imperdibles.
        </p>

        <h3>1. Hollow Knight: Silksong</h3>
        <p>
          Después de años de espera, la secuela de Hollow Knight finalmente llegó y superó 
          todas las expectativas. Con nuevos personajes, mecánicas mejoradas y un mundo 
          aún más expansivo, este metroidvania es una obra maestra del género.
        </p>

        <h3>2. Celeste: Chapter 9</h3>
        <p>
          Una expansión gratuita del clásico plataformero que añade horas de contenido 
          desafiante. Si amaste el juego original, este nuevo capítulo es obligatorio.
        </p>

        <h3>3. Hades 2</h3>
        <p>
          Supergiant Games vuelve con una secuela que mejora todo lo que hizo grande al 
          original. Más dioses, más armas, más historias entrelazadas en el Inframundo griego.
        </p>

        <h3>4. Stardew Valley: Haunted Chocolatier</h3>
        <p>
          ConcernedApe está de vuelta con un nuevo proyecto que combina simulación de granja 
          con elementos de acción RPG. Aunque aún en desarrollo, las previews muestran un 
          juego prometedor.
        </p>

        <h3>5. Sea of Stars</h3>
        <p>
          Un RPG por turnos con inspiración en los clásicos de los 90s pero con mecánicas 
          modernas. Su sistema de combate dinámico y su historia emotiva lo convierten en 
          un must-play.
        </p>

        <h3>¿Por qué jugar indie?</h3>
        <p>
          Los juegos indie ofrecen experiencias únicas que los grandes estudios raramente 
          se atreven a intentar. Son más experimentales, personales y a menudo más 
          memorables que muchos títulos AAA.
        </p>

        <h3>Dónde encontrarlos</h3>
        <p>
          Todos estos títulos están disponibles en PC (Steam), Nintendo Switch, PlayStation 
          y Xbox. En Level-Up Gamer ofrecemos gift cards para todas las plataformas para 
          que puedas disfrutar de estas joyas indie.
        </p>
      `,
      categoria: 'Juegos',
      imagen: '🕹️'
    }
  };

  const articulo = articulos[id];

  if (!articulo) {
    return (
      <>
        <Header />
        <main className="section">
          <h1 className="section-title">Artículo no encontrado</h1>
          <Link to="/blog" className="btn-primary">← Volver al Blog</Link>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      
      <main className="section">
        <article style={{maxWidth: '800px', margin: '0 auto'}}>
          <Link to="/blog" style={{
            display: 'inline-block',
            marginBottom: '20px',
            color: '#ff6b6b',
            textDecoration: 'none',
            fontWeight: 'bold'
          }}>
            ← Volver al Blog
          </Link>

          <div style={{
            width: '100%',
            height: '300px',
            background: `linear-gradient(135deg, ${id === '1' ? '#667eea, #764ba2' : id === '2' ? '#f093fb, #f5576c' : '#4facfe, #00f2fe'})`,
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '120px',
            marginBottom: '30px'
          }}>
            {articulo.imagen}
          </div>

          <div className="card" style={{textAlign: 'left'}}>
            <div style={{
              display: 'flex',
              gap: '15px',
              marginBottom: '15px',
              fontSize: '0.9em',
              color: '#666'
            }}>
              <span>📅 {articulo.fecha}</span>
              <span>✍️ {articulo.autor}</span>
              <span style={{
                background: '#ff6b6b',
                color: 'white',
                padding: '2px 10px',
                borderRadius: '12px',
                fontSize: '0.85em'
              }}>
                {articulo.categoria}
              </span>
            </div>

            <h1 style={{marginBottom: '30px', fontSize: '2.5em', lineHeight: '1.2'}}>
              {articulo.titulo}
            </h1>

            <div 
              style={{lineHeight: '1.8', fontSize: '1.1em'}}
              dangerouslySetInnerHTML={{__html: articulo.contenido}}
            />

            <hr style={{margin: '40px 0', border: 'none', borderTop: '1px solid #ddd'}} />

            <div style={{
              background: '#f8f9fa',
              padding: '20px',
              borderRadius: '8px',
              textAlign: 'center'
            }}>
              <h3 style={{marginBottom: '15px'}}>¿Te gustó este artículo?</h3>
              <p style={{marginBottom: '20px', color: '#666'}}>
                Encuentra todos los productos mencionados en nuestra tienda
              </p>
              <Link to="/" className="btn-primary">
                Volver al Inicio →
              </Link>
            </div>
          </div>
        </article>
      </main>

      <Footer />
    </>
  );
}

export default BlogArticulo;
