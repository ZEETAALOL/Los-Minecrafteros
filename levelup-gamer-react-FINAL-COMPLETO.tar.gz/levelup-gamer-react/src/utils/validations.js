// Validación de RUN chileno (sin puntos ni guion)
export function validarRUN(run) {
  // Primero hacer trim y uppercase, luego limpiar caracteres no permitidos
  const clean = (run || '').trim().toUpperCase().replace(/[^0-9K]/g, '');
  
  // Validar longitud (mínimo 7, máximo 9 caracteres)
  if (clean.length < 7 || clean.length > 9) return false;
  
  // Separar el cuerpo del dígito verificador
  const cuerpo = clean.slice(0, -1);
  const dv = clean.slice(-1);
  
  // Validar que el cuerpo solo contenga números
  if (!/^\d+$/.test(cuerpo)) return false;
  
  // Calcular el dígito verificador
  let suma = 0;
  let multiplicador = 2;
  
  // Recorrer el cuerpo de derecha a izquierda
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += parseInt(cuerpo[i]) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }
  
  // Calcular el dígito verificador esperado
  const resto = suma % 11;
  const dvEsperado = 11 - resto;
  
  let digitoVerificador;
  if (dvEsperado === 11) {
    digitoVerificador = '0';
  } else if (dvEsperado === 10) {
    digitoVerificador = 'K';
  } else {
    digitoVerificador = dvEsperado.toString();
  }
  
  // Comparar el dígito verificador ingresado con el calculado
  return dv === digitoVerificador;
}

// Validación de correos permitidos
export function validarCorreo(correo) {
  return /@(duocuc\.cl|profesor\.duoc\.cl|gmail\.com)$/.test(correo);
}

// Validación de contraseña
export function validarPassword(password) {
  return password.length >= 4 && password.length <= 10;
}
