import { useLocalStorage } from './useLocalStorage';

/**
 * Hook para gestionar el sistema de reseñas de productos
 */
export function useReviews() {
  const [reviews, setReviews] = useLocalStorage('productReviews', {});

  /**
   * Obtiene todas las reseñas de un producto
   */
  const getProductReviews = (productId) => {
    if (!productId) return [];
    return reviews[productId] || [];
  };

  /**
   * Calcula el promedio de calificación de un producto
   */
  const getProductRating = (productId) => {
    const productReviews = getProductReviews(productId);
    if (productReviews.length === 0) return 0;
    
    const sum = productReviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / productReviews.length).toFixed(1);
  };

  /**
   * Verifica si un usuario ya ha reseñado un producto
   */
  const hasUserReviewed = (productId, userId) => {
    const productReviews = getProductReviews(productId);
    return productReviews.some(review => review.userId === userId);
  };

  /**
   * Agrega una nueva reseña
   */
  const addReview = (productId, userId, userName, rating, comment) => {
    if (!productId || !userId) {
      return { success: false, message: 'Datos inválidos' };
    }

    if (rating < 1 || rating > 5) {
      return { success: false, message: 'La calificación debe estar entre 1 y 5' };
    }

    if (hasUserReviewed(productId, userId)) {
      return { success: false, message: 'Ya has dejado una reseña para este producto' };
    }

    const newReview = {
      id: Date.now(),
      userId,
      userName: userName || 'Usuario',
      rating,
      comment: comment || '',
      date: new Date().toISOString(),
      helpful: 0
    };

    setReviews(prev => ({
      ...prev,
      [productId]: [...(prev[productId] || []), newReview]
    }));

    return { success: true, message: '¡Reseña agregada con éxito!' };
  };

  /**
   * Edita una reseña existente
   */
  const editReview = (productId, reviewId, userId, rating, comment) => {
    const productReviews = getProductReviews(productId);
    const review = productReviews.find(r => r.id === reviewId);

    if (!review) {
      return { success: false, message: 'Reseña no encontrada' };
    }

    if (review.userId !== userId) {
      return { success: false, message: 'No puedes editar esta reseña' };
    }

    if (rating < 1 || rating > 5) {
      return { success: false, message: 'La calificación debe estar entre 1 y 5' };
    }

    setReviews(prev => ({
      ...prev,
      [productId]: prev[productId].map(r => 
        r.id === reviewId 
          ? { ...r, rating, comment, editedAt: new Date().toISOString() }
          : r
      )
    }));

    return { success: true, message: 'Reseña actualizada' };
  };

  /**
   * Elimina una reseña
   */
  const deleteReview = (productId, reviewId, userId) => {
    const productReviews = getProductReviews(productId);
    const review = productReviews.find(r => r.id === reviewId);

    if (!review) {
      return { success: false, message: 'Reseña no encontrada' };
    }

    if (review.userId !== userId) {
      return { success: false, message: 'No puedes eliminar esta reseña' };
    }

    setReviews(prev => ({
      ...prev,
      [productId]: prev[productId].filter(r => r.id !== reviewId)
    }));

    return { success: true, message: 'Reseña eliminada' };
  };

  /**
   * Marca una reseña como útil
   */
  const markAsHelpful = (productId, reviewId) => {
    setReviews(prev => ({
      ...prev,
      [productId]: prev[productId].map(r => 
        r.id === reviewId 
          ? { ...r, helpful: r.helpful + 1 }
          : r
      )
    }));
  };

  return {
    getProductReviews,
    getProductRating,
    hasUserReviewed,
    addReview,
    editReview,
    deleteReview,
    markAsHelpful
  };
}
