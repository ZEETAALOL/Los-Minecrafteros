import { useLocalStorage } from './useLocalStorage';

const POINTS_PER_1000_CLP = 1; // 1 punto por cada $1000 gastados
const POINTS_TO_DISCOUNT = 100; // 100 puntos = $10.000 descuento

/**
 * Hook para gestionar el sistema de puntos de fidelidad
 */
export function useLoyaltyPoints() {
  const [loyaltyData, setLoyaltyData] = useLocalStorage('loyaltyPoints', {});

  /**
   * Obtiene los puntos de un usuario
   */
  const getUserPoints = (userId) => {
    if (!userId) return 0;
    return loyaltyData[userId]?.points || 0;
  };

  /**
   * Obtiene el historial de transacciones de puntos de un usuario
   */
  const getUserHistory = (userId) => {
    if (!userId) return [];
    return loyaltyData[userId]?.history || [];
  };

  /**
   * Agrega puntos a un usuario basado en el monto de compra
   */
  const addPointsFromPurchase = (userId, totalAmount) => {
    if (!userId || totalAmount <= 0) return;

    const pointsEarned = Math.floor(totalAmount / 1000) * POINTS_PER_1000_CLP;
    
    setLoyaltyData(prev => {
      const userData = prev[userId] || { points: 0, history: [] };
      const newPoints = userData.points + pointsEarned;
      
      const transaction = {
        id: Date.now(),
        date: new Date().toISOString(),
        type: 'earn',
        points: pointsEarned,
        amount: totalAmount,
        description: `Compra de ${new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(totalAmount)}`
      };

      return {
        ...prev,
        [userId]: {
          points: newPoints,
          history: [transaction, ...userData.history]
        }
      };
    });

    return pointsEarned;
  };

  /**
   * Canjea puntos por descuento
   */
  const redeemPoints = (userId, pointsToRedeem) => {
    if (!userId || pointsToRedeem <= 0) return { success: false, message: 'Puntos inválidos' };

    const currentPoints = getUserPoints(userId);
    
    if (pointsToRedeem > currentPoints) {
      return { success: false, message: 'No tienes suficientes puntos' };
    }

    if (pointsToRedeem % POINTS_TO_DISCOUNT !== 0) {
      return { 
        success: false, 
        message: `Los puntos deben ser múltiplos de ${POINTS_TO_DISCOUNT}` 
      };
    }

    const discountAmount = (pointsToRedeem / POINTS_TO_DISCOUNT) * 10000;

    setLoyaltyData(prev => {
      const userData = prev[userId];
      const newPoints = userData.points - pointsToRedeem;

      const transaction = {
        id: Date.now(),
        date: new Date().toISOString(),
        type: 'redeem',
        points: -pointsToRedeem,
        amount: discountAmount,
        description: `Descuento de ${new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(discountAmount)}`
      };

      return {
        ...prev,
        [userId]: {
          points: newPoints,
          history: [transaction, ...userData.history]
        }
      };
    });

    return { 
      success: true, 
      discountAmount, 
      message: `¡${pointsToRedeem} puntos canjeados por ${new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(discountAmount)}!` 
    };
  };

  /**
   * Calcula el descuento máximo disponible
   */
  const getMaxDiscount = (userId) => {
    const points = getUserPoints(userId);
    const redeemablePoints = Math.floor(points / POINTS_TO_DISCOUNT) * POINTS_TO_DISCOUNT;
    return (redeemablePoints / POINTS_TO_DISCOUNT) * 10000;
  };

  return {
    getUserPoints,
    getUserHistory,
    addPointsFromPurchase,
    redeemPoints,
    getMaxDiscount,
    POINTS_PER_1000_CLP,
    POINTS_TO_DISCOUNT
  };
}
