import { useState, useEffect } from 'react';

const LS_CART = 'carrito';

export function useCart() {
  const [cart, setCart] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(LS_CART)) || [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(LS_CART, JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product) => {
    setCart(prev => [...prev, { 
      id: product.id, 
      nombre: product.nombre, 
      precio: product.precio 
    }]);
  };

  const removeFromCart = (id) => {
    setCart(prev => {
      const idx = prev.findIndex(item => item.id === id);
      if (idx >= 0) {
        const newCart = [...prev];
        newCart.splice(idx, 1);
        return newCart;
      }
      return prev;
    });
  };

  const setQuantity = (id, qty) => {
    const products = JSON.parse(localStorage.getItem('productosData')) || [];
    const product = products.find(p => p.id === id);
    if (!product) return;

    const newCart = [];
    for (let i = 0; i < Math.max(0, parseInt(qty, 10)); i++) {
      newCart.push({ id: product.id, nombre: product.nombre, precio: product.precio });
    }
    
    setCart(prev => [
      ...prev.filter(item => item.id !== id),
      ...newCart
    ]);
  };

  const clearCart = () => {
    setCart([]);
  };

  const groupedCart = () => {
    const map = new Map();
    cart.forEach(item => {
      const key = item.id;
      const g = map.get(key) || { id: item.id, nombre: item.nombre, precio: item.precio, qty: 0 };
      g.qty += 1;
      map.set(key, g);
    });
    return Array.from(map.values());
  };

  const cartCount = cart.length;

  return {
    cart,
    cartCount,
    addToCart,
    removeFromCart,
    setQuantity,
    clearCart,
    groupedCart
  };
}
