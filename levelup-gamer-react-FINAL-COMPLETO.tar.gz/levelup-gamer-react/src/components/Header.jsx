import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart';
import { useSession } from '../hooks/useLocalStorage';
import { useLoyaltyPoints } from '../hooks/useLoyaltyPoints';

function Header() {
  const { cartCount } = useCart();
  const { session } = useSession();
  const { getUserPoints } = useLoyaltyPoints();
  
  const userPoints = session ? getUserPoints(session.id) : 0;

  return (
    <header className="site-header">
      <div className="brand">
        <span className="logo"></span>
        <Link className="brand-name" to="/">Level-Up Gamer</Link>
      </div>
      <nav className="main-nav">
        <Link to="/">Home</Link>
        <Link to="/productos">Productos</Link>
        <Link to="/registro">Registro</Link>
        <Link to="/login">Login</Link>
        <Link to="/nosotros">Nosotros</Link>
        <Link to="/blog">Blog</Link>
        <Link to="/contacto">Contacto</Link>
        <Link to="/admin" className="admin-link">Admin</Link>
      </nav>
      <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
        {session && (
          <Link 
            to="/mis-puntos" 
            style={{ 
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '8px 16px',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              borderRadius: '20px',
              color: '#fff',
              textDecoration: 'none',
              fontWeight: '600',
              fontSize: '0.9em',
              transition: 'transform 0.2s'
            }}
            onMouseEnter={(e) => e.target.style.transform = 'scale(1.05)'}
            onMouseLeave={(e) => e.target.style.transform = 'scale(1)'}
          >
            💎 {userPoints} pts
          </Link>
        )}
        <Link to="/carrito" className="cart-badge">
          🛒<span id="cartCount">{cartCount}</span>
        </Link>
      </div>
    </header>
  );
}

export default Header;
