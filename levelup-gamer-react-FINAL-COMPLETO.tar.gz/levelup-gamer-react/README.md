# Level-Up Gamer - Tienda Online con React + Vite

Proyecto de tienda online para gamers, migrado de HTML/CSS/JS vanilla a **React + Vite**.

## 🚀 Características

- ✅ Tienda online con catálogo de productos
- ✅ Sistema de carrito de compras con localStorage
- ✅ Validaciones de formularios con JavaScript
- ✅ Autenticación de usuarios (Login/Registro)
- ✅ Panel de administración (CRUD Productos y Usuarios)
- ✅ Descuento automático 20% para correos @duoc.cl
- ✅ Mapa interactivo con Leaflet para dirección de envío
- ✅ Validación de RUN chileno
- ✅ Roles de usuario: Administrador, Vendedor, Cliente
- ✅ Diseño responsivo

## 📋 Requisitos

- Node.js 16+ 
- npm o yarn

## 🔧 Instalación

1. **Clonar/descargar el proyecto**

2. **Instalar dependencias:**
```bash
npm install
```

3. **Iniciar servidor de desarrollo:**
```bash
npm run dev
```

El proyecto se abrirá automáticamente en `http://localhost:3000`

## 📦 Construir para producción

```bash
npm run build
```

Los archivos optimizados estarán en la carpeta `dist/`

## 🗂️ Estructura del proyecto

```
levelup-gamer-react/
├── public/
│   └── img/                    # Imágenes del proyecto
├── src/
│   ├── components/            # Componentes reutilizables
│   │   ├── Header.jsx
│   │   ├── Footer.jsx
│   │   └── AdminHeader.jsx
│   ├── hooks/                 # Custom hooks
│   │   ├── useCart.js
│   │   └── useLocalStorage.js
│   ├── pages/                 # Páginas principales
│   │   ├── Home.jsx
│   │   ├── Productos.jsx
│   │   ├── Registro.jsx
│   │   ├── Login.jsx
│   │   ├── Nosotros.jsx
│   │   ├── Blog.jsx
│   │   ├── Contacto.jsx
│   │   ├── Carrito.jsx
│   │   └── admin/            # Páginas de administración
│   │       ├── AdminHome.jsx
│   │       ├── AdminProductos.jsx
│   │       └── AdminUsuarios.jsx
│   ├── utils/                # Utilidades
│   │   └── validations.js
│   ├── App.jsx               # Componente principal con rutas
│   ├── main.jsx              # Punto de entrada
│   └── styles.css            # Estilos globales
├── index.html
├── package.json
└── vite.config.js
```

## 👥 Usuarios de prueba

### Administrador
- **Correo:** admin@gmail.com
- **Contraseña:** 1234

### Vendedor
- **Correo:** vendedor@gmail.com
- **Contraseña:** 1234

### Cliente
- **Correo:** cliente@gmail.com
- **Contraseña:** 1234

## 🛠️ Tecnologías utilizadas

- **React 18** - Librería UI
- **Vite** - Build tool y dev server
- **React Router DOM** - Enrutamiento
- **Leaflet + React Leaflet** - Mapas interactivos
- **LocalStorage** - Persistencia de datos

## 📝 Funcionalidades principales

### Tienda
- Catálogo de productos con filtros por categoría y búsqueda
- Carrito de compras persistente
- Sistema de descuentos automático (20% OFF para @duoc.cl)
- Mapa interactivo para seleccionar dirección de envío
- Detalle de productos con stock crítico

### Autenticación
- Registro de usuarios con validación de RUN
- Login con sesión persistente
- Validación de correos permitidos (@duoc.cl, @profesor.duoc.cl, @gmail.com)

### Panel de Administración
- **CRUD Productos:** Crear, editar, eliminar productos
- **CRUD Usuarios:** Gestión completa de usuarios (solo Admin)
- Validaciones en tiempo real
- Alertas de stock crítico

## 🔐 Validaciones implementadas

### Registro/Usuario
- RUN chileno válido (algoritmo verificador)
- Correos permitidos: @duoc.cl, @profesor.duoc.cl, @gmail.com
- Contraseña: 4-10 caracteres
- Campos con límites de caracteres

### Productos
- Código único (min 3 caracteres)
- Precio y stock numéricos válidos
- Stock crítico opcional
- Categoría requerida

### Contacto
- Nombre máx 100 caracteres
- Correo validado
- Comentario máx 500 caracteres

## 📱 Responsive Design

El proyecto está optimizado para:
- 📱 Móviles (320px+)
- 📱 Tablets (768px+)
- 💻 Desktop (1024px+)

## 🎨 Personalización

Los colores principales se pueden modificar en `src/styles.css`:

```css
:root {
  --bg: #141315;
  --text: #fff;
  --primary: #bd2eff;
  --accent: #5855fe;
  --card: #000000;
}
```

## 📄 Licencia

Este proyecto fue desarrollado como parte de la Evaluación Parcial 1 del curso DSY1104.

## 👨‍💻 Desarrolladores

- Bastian Martinez
- Benjamin Palma

---

**Level-Up Gamer** © 2025
