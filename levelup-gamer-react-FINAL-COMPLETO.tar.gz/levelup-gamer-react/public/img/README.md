# Imágenes necesarias

Coloca las siguientes imágenes en esta carpeta `/public/img/`:

## Productos
- catan.jpg
- carcassonne.jpg
- xbox-controller.jpg
- hyperx-cloud2.jpg
- ps5.jpg
- asus-rog-strix.jpg
- silla.jpg
- logitech-g502-hero.jpg
- razer-goliathus.jpg
- polera-levelup.jpg

## Otros
- banner-gamer.jpg (banner principal de la tienda)
- favicon.png (icono del sitio)
- avatar1.jpg (foto del equipo)
- avatar2.jpg (foto del equipo)
- blog1.jpg (imagen blog 1)
- blog2.jpg (imagen blog 2)

**Nota:** Si no tienes las imágenes, la aplicación mostrará un placeholder o imagen por defecto (banner-gamer.jpg).

Puedes usar imágenes de:
- Unsplash.com
- Pexels.com
- O cualquier fuente libre de derechos
