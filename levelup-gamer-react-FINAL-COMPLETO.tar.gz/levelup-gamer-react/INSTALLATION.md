# Guía de Instalación Paso a Paso

## 1. Prerequisitos

Antes de comenzar, asegúrate de tener instalado:

### Instalar Node.js
1. Ve a https://nodejs.org/
2. Descarga la versión LTS (recomendada)
3. Instala siguiendo el asistente
4. Verifica la instalación abriendo una terminal y ejecutando:
```bash
node --version
npm --version
```

Deberías ver algo como:
```
v18.17.0
9.8.1
```

## 2. Descargar el Proyecto

Opción A - Con Git:
```bash
git clone [URL_DEL_REPOSITORIO]
cd levelup-gamer-react
```

Opción B - Sin Git:
1. Descarga el proyecto como ZIP
2. Extrae el contenido
3. Abre una terminal en la carpeta del proyecto

## 3. Instalar Dependencias

En la terminal, dentro de la carpeta del proyecto, ejecuta:

```bash
npm install
```

Este proceso puede tomar varios minutos. Descargará todas las librerías necesarias.

## 4. Agregar Imágenes (Opcional)

1. Navega a la carpeta `public/img/`
2. Agrega las imágenes según lo indicado en `public/img/README.md`
3. Si no tienes imágenes, la app usará placeholders

## 5. Iniciar el Servidor de Desarrollo

```bash
npm run dev
```

Verás algo como:
```
VITE v5.0.8  ready in 500 ms

➜  Local:   http://localhost:3000/
➜  Network: use --host to expose
➜  press h + enter to show help
```

## 6. Abrir en el Navegador

1. Abre tu navegador (Chrome, Firefox, Edge, etc.)
2. Ve a: `http://localhost:3000`
3. ¡Listo! La aplicación debería estar funcionando

## 7. Usuarios de Prueba

### Administrador
- **Correo:** admin@gmail.com
- **Contraseña:** 1234
- **Permisos:** Acceso completo

### Vendedor
- **Correo:** vendedor@gmail.com
- **Contraseña:** 1234
- **Permisos:** Ver y gestionar productos

### Cliente
- **Correo:** cliente@gmail.com
- **Contraseña:** 1234
- **Permisos:** Comprar en la tienda

## 8. Probar Funcionalidades

### Como Cliente:
1. Navega por los productos
2. Añade productos al carrito
3. Ve al carrito y prueba el checkout con mapa

### Como Admin:
1. Inicia sesión con admin@gmail.com / 1234
2. Ve al panel de administración
3. Prueba crear, editar y eliminar productos
4. Gestiona usuarios

## 9. Construir para Producción

Cuando quieras crear la versión final:

```bash
npm run build
```

Los archivos optimizados estarán en la carpeta `dist/`

## 10. Solución de Problemas Comunes

### Error: "npm no se reconoce como comando"
- Solución: Reinstala Node.js desde nodejs.org

### Error: "port 3000 already in use"
- Solución: Cierra otros programas usando el puerto 3000 o cambia el puerto en `vite.config.js`

### Error: "Cannot find module..."
- Solución: Ejecuta `npm install` nuevamente

### Las imágenes no se ven
- Solución: Verifica que las imágenes estén en `/public/img/`

### El carrito se vacía al recargar
- Esto es normal si abres con `file://`
- Solución: Usa siempre `npm run dev`

## 11. Comandos Útiles

```bash
# Iniciar servidor de desarrollo
npm run dev

# Construir para producción
npm run build

# Preview de producción
npm run preview

# Limpiar node_modules e instalar de nuevo
rm -rf node_modules
npm install
```

## ¿Necesitas Ayuda?

- Lee el archivo README.md principal
- Revisa la documentación de React: https://react.dev
- Revisa la documentación de Vite: https://vitejs.dev

---

¡Disfruta desarrollando con Level-Up Gamer! 🎮
