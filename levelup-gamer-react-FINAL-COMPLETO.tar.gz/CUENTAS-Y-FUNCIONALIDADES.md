# 🎮 Level-Up Gamer - Cuentas de Prueba y Funcionalidades

## 👥 CUENTAS DE PRUEBA

### 🔐 Administrador
```
Correo: admin@gmail.com
Contraseña: 1234
RUN: 19011022K
Tipo: Administrador
```
**Permisos:**
- Acceso al panel de administración
- Gestión de productos (crear, editar, eliminar)
- Gestión de usuarios
- Ver todas las estadísticas

---

### 💼 Vendedor
```
Correo: vendedor@gmail.com
Contraseña: 1234
RUN: 141234560
Tipo: Vendedor
```
**Permisos:**
- Acceso al panel de administración
- Gestión de productos
- Ver estadísticas de ventas

---

### 🛒 Cliente
```
Correo: cliente@gmail.com
Contraseña: 1234
RUN: 130000009
Tipo: Cliente
```
**Permisos:**
- Comprar productos
- Acumular puntos de fidelidad
- Ver su historial de compras

---

## ✨ NUEVAS FUNCIONALIDADES IMPLEMENTADAS

### 1. 📦 **Descuento Automático de Stock**
✅ **Implementado**

Ahora cuando un cliente realiza una compra:
- El stock de cada producto se descuenta automáticamente
- Se valida que haya stock suficiente antes de confirmar la compra
- Si no hay stock suficiente, se muestra un mensaje de alerta
- El stock actualizado se guarda en localStorage
- Los administradores pueden ver el stock actualizado en tiempo real

**Ejemplo:**
- PlayStation 5 tiene 8 unidades en stock
- Cliente compra 2 unidades
- Stock actualizado: 6 unidades

---

### 2. 📧 **Correo Duoc UC Actualizado**
✅ **Corregido**

Se actualizó la validación de correos para usar:
- `@duocuc.cl` (anteriormente era @duoc.cl)
- `@profesor.duoc.cl` (sin cambios)
- `@gmail.com` (sin cambios)

Esto aplica en:
- Formulario de registro
- Formulario de contacto
- Validaciones del sistema

---

### 3. 🗺️ **Mapa Interactivo para Envíos**
✅ **Funcionando**

- Integración con Leaflet y OpenStreetMap
- Click en el mapa para seleccionar ubicación exacta de entrega
- Coordenadas GPS guardadas con el pedido
- No requiere API key (usa OpenStreetMap gratuito)

**Ubicación:** Página del carrito de compras

---

### 4. 🖼️ **Imágenes Reales de Productos**
✅ **Agregadas**

Productos con imágenes reales:
- **Catán** → `/img/catan.jpg`
- **Ticket to Ride** → `/img/ticket-to-ride.webp`

---

### 5. 🔗 **Links Corregidos**
✅ **Arreglado**

- Link "Volver al Inicio" en artículos del blog ahora funciona correctamente
- Ya no hay rutas rotas a `/tienda`

---

### 6. ✅ **Validación de RUT Mejorada**
✅ **Corregida**

- Se corrigió el orden de validación para evitar falsos positivos
- Ahora acepta RUT correctamente formateado sin puntos ni guión
- Ejemplo válido: `19011022K`

---

## 🚀 CÓMO USAR EL PANEL DE ADMINISTRACIÓN

1. **Iniciar sesión** con la cuenta de administrador:
   - Email: `admin@gmail.com`
   - Password: `1234`

2. **Acceder al panel:**
   - Después de iniciar sesión, aparecerá un botón "Admin" en el header
   - Click en "Admin" para ir al panel de administración

3. **Gestionar productos:**
   - Ver listado completo de productos
   - Ver stock actual y stock crítico
   - Editar productos existentes
   - Agregar nuevos productos
   - Eliminar productos

4. **Gestionar usuarios:**
   - Ver todos los usuarios registrados
   - Ver tipo de usuario (Administrador, Vendedor, Cliente)
   - Ver información de contacto

---

## 📊 FLUJO DE COMPRA CON DESCUENTO DE STOCK

```
1. Cliente agrega productos al carrito
   ↓
2. Va a la página del carrito
   ↓
3. Ingresa dirección y selecciona punto en el mapa
   ↓
4. (Opcional) Canjea puntos de fidelidad
   ↓
5. Confirma la compra
   ↓
6. SISTEMA VALIDA STOCK DISPONIBLE
   ↓
7. Si hay stock: 
   - Descuenta automáticamente del inventario
   - Guarda el pedido
   - Agrega puntos de fidelidad
   - Muestra mensaje de confirmación
   ↓
8. Si NO hay stock:
   - Muestra alerta
   - No procesa la compra
   - Cliente debe ajustar cantidades
```

---

## 🔍 VERIFICAR EL DESCUENTO DE STOCK

**Pasos para probar:**

1. Iniciar sesión como administrador
2. Ir al panel de administración → Productos
3. Ver el stock de un producto (ejemplo: PlayStation 5 = 8 unidades)
4. Cerrar sesión
5. Iniciar sesión como cliente
6. Agregar 2 PlayStation 5 al carrito
7. Completar la compra
8. Volver a iniciar sesión como administrador
9. Verificar el stock actualizado (ahora debería ser 6 unidades)

---

## 📝 NOTAS IMPORTANTES

- Los datos se guardan en `localStorage` del navegador
- Si limpias el localStorage, los datos vuelven a los valores iniciales
- El stock se actualiza en tiempo real en toda la aplicación
- Los productos con stock 0 se pueden seguir viendo pero no se pueden comprar

---

## 🎯 PRÓXIMAS MEJORAS SUGERIDAS

- [ ] Historial de compras por usuario
- [ ] Notificaciones cuando un producto llegue a stock crítico
- [ ] Reportes de ventas con gráficos
- [ ] Sistema de cupones de descuento
- [ ] Filtros avanzados de búsqueda

---

**Última actualización:** 28 de Octubre, 2025
